// LuauHost.cpp - sandboxed embedding of the official Luau compiler + VM.
//
// Sandbox model (verified against Luau 0.746 sources):
//   * lua_newstate() with a budgeted lua_Alloc -> hard memory limit
//   * luaL_openlibs() + luaL_sandbox() -> frozen standard libraries
//   * lua_newthread() + luaL_sandboxthread() -> per-run proxy globals;
//     scripts can assign globals freely but reads fall through to the
//     frozen builtin tables and nothing persists past the run
//   * lua_callbacks()->interrupt -> official time-limit safepoint; raising a
//     Lua error from it unwinds cleanly into lua_pcall (same pattern the
//     official CLI uses for Ctrl-C)
//   * Luau::compile() + luau_load() -> bytecode is compiler-validated, there
//     is no raw-binary loading path and no FFI/io network surface
#include "luauhost.h"

#include "lua.h"
#include "lualib.h"

#include "Luau/Common.h"
#include "Luau/Compiler.h"
#include "Luau/ExperimentalFlags.h"
#include "Luau/BytecodeBuilder.h"
#include "Luau/Parser.h"

#include <atomic>
#include <chrono>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <mutex>
#include <string>
#include <new>

namespace
{

const char* kVersion = "LuauHost 1.0.0 (Luau 0.746)";

constexpr size_t kMinMemoryLimit = size_t(1) * 1024 * 1024;
constexpr size_t kMaxMemoryLimit = size_t(4) * 1024 * 1024 * 1024; // 4 GB (size_t arithmetic: 4u*... would overflow 32-bit)
constexpr size_t kMaxErrorMessage = 16u * 1024u;
constexpr size_t kTracebackDepthMessageCap = kMaxErrorMessage;

struct MemContext
{
    size_t budget = 0;
    size_t used = 0;
};

struct Session
{
    LuauHostConfig config{};

    std::atomic<bool> cancel{false};
    std::atomic<bool> running{false};
    std::atomic<size_t> outputBytes{0};
    std::atomic<bool> outputTruncated{false};

    // Valid only while running == true (single execute at a time).
    MemContext mem;
    std::chrono::steady_clock::time_point deadline;
};

// One execute at a time per thread; print/warn/http_get/loadstring retrieve
// their session through this pointer instead of per-function upvalues.
thread_local Session* t_session = nullptr;

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

// Official CLI fast-flag default: enable all non-experimental "Luau*" flags
// so the embedded runtime matches a current release build (integer library,
// newer parser features, ...). See luau-lang/luau CLI/src/Flags.cpp.
void enableDefaultFlags()
{
    static std::once_flag once;
    std::call_once(
        once,
        []()
        {
            for (Luau::FValue<bool>* flag = Luau::FValue<bool>::list; flag; flag = flag->next)
                if (strncmp(flag->name, "Luau", 4) == 0 && !Luau::isAnalysisFlagExperimental(flag->name))
                    flag->value = true;
        }
    );
}

// Error formatting mirrors the official luau CLI: "name(line,col): SyntaxError: msg"
std::string formatLocationError(const char* chunkName, const char* kind, unsigned int line, unsigned int column, const char* message)
{
    char buffer[160];
    snprintf(buffer, sizeof(buffer), "%s(%u,%u): %s: ", chunkName, line, column, kind);
    return std::string(buffer) + (message ? message : "");
}

std::string formatCompileError(const char* chunkName, const Luau::CompileError& error)
{
    const Luau::Position& begin = error.getLocation().begin;
    return formatLocationError(chunkName, "SyntaxError", begin.line + 1, begin.column + 1, error.what());
}

std::string formatParseError(const char* chunkName, const Luau::ParseError& error)
{
    const Luau::Position& begin = error.getLocation().begin;
    return formatLocationError(chunkName, "SyntaxError", begin.line + 1, begin.column + 1, error.what());
}

void copyErrorMessage(const std::string& message, char* errorBuffer, size_t errorBufferCapacity, size_t* errorLength)
{
    if (errorLength)
        *errorLength = 0;

    if (!errorBuffer || errorBufferCapacity == 0)
        return;

    size_t length = message.size() < kMaxErrorMessage ? message.size() : kMaxErrorMessage;
    length = length < errorBufferCapacity - 1 ? length : errorBufferCapacity - 1;
    memcpy(errorBuffer, message.data(), length);
    errorBuffer[length] = '\0';

    if (errorLength)
        *errorLength = length;
}

void emitOutput(Session* session, int channel, const char* data, size_t length)
{
    if (!session->config.onOutput || length == 0)
        return;

    const size_t cap = session->config.maxOutputBytes;
    const size_t previous = session->outputBytes.load(std::memory_order_relaxed);

    if (cap != 0 && previous >= cap)
    {
        session->outputTruncated.store(true, std::memory_order_relaxed);
        return;
    }

    size_t emitLength = length;
    if (cap != 0 && previous + length > cap)
        emitLength = cap - previous;

    session->outputBytes.fetch_add(emitLength, std::memory_order_relaxed);
    session->config.onOutput(session->config.callbackContext, channel, data, emitLength);

    if (cap != 0 && previous + length > cap)
        session->outputTruncated.store(true, std::memory_order_relaxed);
}

// ---------------------------------------------------------------------------
// Lua C functions exposed to scripts
// ---------------------------------------------------------------------------

// budgeted allocator: allocation failure inside the VM raises a catchable
// LUA_ERRMEM error (VM/src/lmem.cpp throws through luaD_throw)
void* luaAlloc(void* ud, void* ptr, size_t osize, size_t nsize)
{
    MemContext* mem = static_cast<MemContext*>(ud);

    if (nsize == 0)
    {
        if (ptr)
        {
            mem->used -= osize;
            std::free(ptr);
        }
        return nullptr;
    }

    const size_t accounted = ptr ? osize : 0;

    if (mem->used - accounted + nsize > mem->budget)
        return nullptr;

    void* reallocated = std::realloc(ptr, nsize);
    if (reallocated)
        mem->used += nsize - accounted;

    return reallocated;
}

void interrupt(lua_State* L, int gc)
{
    // GC safepoints never abort (official pattern, CLI/src/Repl.cpp)
    if (gc >= 0)
        return;

    Session* session = t_session;
    if (!session)
        return;

    if (session->cancel.load(std::memory_order_relaxed))
    {
        lua_rawcheckstack(L, 1); // reserve space for the error string
        luaL_error(L, "execution cancelled by user");
    }

    if (std::chrono::steady_clock::now() >= session->deadline)
    {
        lua_rawcheckstack(L, 1);
        luaL_error(L, "execution timed out (limit %.2f s)", session->config.timeLimitSeconds);
    }
}

int lf_print(lua_State* L)
{
    Session* session = t_session;

    luaL_Strbuf buffer;
    luaL_buffinit(L, &buffer);

    const int count = lua_gettop(L);
    for (int i = 1; i <= count; ++i)
    {
        if (i > 1)
            luaL_addstring(&buffer, "\t");

        size_t length = 0;
        const char* str = luaL_tolstring(L, i, &length);
        luaL_addlstring(&buffer, str, length);
        lua_pop(L, 1);
    }

    luaL_addchar(&buffer, '\n');
    luaL_pushresult(&buffer);

    size_t length = 0;
    const char* str = lua_tolstring(L, -1, &length);
    if (session && str)
        emitOutput(session, LUAUHOST_CHANNEL_PRINT, str, length);

    return 0;
}

int lf_warn(lua_State* L)
{
    Session* session = t_session;

    luaL_Strbuf buffer;
    luaL_buffinit(L, &buffer);

    const int count = lua_gettop(L);
    for (int i = 1; i <= count; ++i)
    {
        if (i > 1)
            luaL_addstring(&buffer, " ");

        size_t length = 0;
        const char* str = luaL_tolstring(L, i, &length);
        luaL_addlstring(&buffer, str, length);
        lua_pop(L, 1);
    }

    luaL_addchar(&buffer, '\n');
    luaL_pushresult(&buffer);

    size_t length = 0;
    const char* str = lua_tolstring(L, -1, &length);
    if (session && str)
        emitOutput(session, LUAUHOST_CHANNEL_WARN, str, length);

    return 0;
}

int lf_httpget(lua_State* L)
{
    Session* session = t_session;

    if (!session || !session->config.onHttp)
        luaL_error(L, "http_get is not available in this session");

    size_t urlLength = 0;
    const char* url = luaL_checklstring(L, 1, &urlLength);

    if (urlLength < 8 || (strncmp(url, "http://", 7) != 0 && strncmp(url, "https://", 8) != 0))
        luaL_error(L, "http_get: url must start with http:// or https://");

    char* body = nullptr;
    size_t bodyLength = 0;
    char* errorText = nullptr;

    const int ok = session->config.onHttp(session->config.callbackContext, url, &body, &bodyLength, &errorText);

    if (!ok)
    {
        std::string message = errorText ? std::string("http_get failed: ") + errorText : std::string("http_get failed");
        if (errorText)
            luauhost_free(errorText);
        luaL_error(L, "%s", message.c_str());
    }

    lua_pushlstring(L, body ? body : "", bodyLength);
    if (body)
        luauhost_free(body);

    return 1;
}

// loadstring, following the official REPL implementation (CLI/src/Repl.cpp):
// compiles with the production compiler and loads compiler-validated bytecode.
int lf_loadstring(lua_State* L)
{
    size_t length = 0;
    const char* source = luaL_checklstring(L, 1, &length);
    const char* chunkName = luaL_optstring(L, 2, "=loadstring");

    lua_setsafeenv(L, LUA_ENVIRONINDEX, false);

    Luau::CompileOptions options{};
    options.optimizationLevel = 1;
    options.debugLevel = 1;

    std::string bytecode = Luau::compile(std::string(source, length), options);
    if (luau_load(L, chunkName, bytecode.data(), bytecode.size(), 0) == 0)
        return 1;

    lua_pushnil(L);
    lua_insert(L, -2); // nil before error message
    return 2;
}

// pcall error handler: stringifies the error object and appends a traceback
int errorHandler(lua_State* L)
{
    size_t length = 0;
    const char* message = luaL_tolstring(L, 1, &length); // pushes tostring result
    luaL_traceback(L, L, message, 1);                    // pushes full message + traceback

    lua_replace(L, 1); // replace error object with the full text
    lua_settop(L, 1);  // drop the intermediate tostring result
    return 1;
}

// ---------------------------------------------------------------------------
// Session lifecycle
// ---------------------------------------------------------------------------

int mapPcallStatus(int status, const std::string& message)
{
    if (status == LUA_ERRMEM)
        return LUAUHOST_MEMORY_LIMIT;
    if (message.rfind("execution timed out", 0) == 0)
        return LUAUHOST_TIMEOUT;
    if (message.rfind("execution cancelled", 0) == 0)
        return LUAUHOST_CANCELLED;
    return LUAUHOST_RUNTIME_ERROR;
}

} // namespace

// ---------------------------------------------------------------------------
// C API
// ---------------------------------------------------------------------------

extern "C" {

void* luauhost_session_create(const LuauHostConfig* config)
{
    if (!config || !config->onOutput || config->timeLimitSeconds <= 0.0 || config->memoryLimitBytes == 0)
        return nullptr;

    Session* session = new (std::nothrow) Session();
    if (!session)
        return nullptr;

    session->config = *config;

    double seconds = config->timeLimitSeconds;
    if (seconds < 0.1)
        seconds = 0.1;
    if (seconds > 3600.0)
        seconds = 3600.0;
    session->config.timeLimitSeconds = seconds;

    size_t memory = config->memoryLimitBytes;
    if (memory < kMinMemoryLimit)
        memory = kMinMemoryLimit;
    if (memory > kMaxMemoryLimit)
        memory = kMaxMemoryLimit;
    session->config.memoryLimitBytes = memory;

    return session;
}

int luauhost_session_execute(void* handle, const char* chunkName, const char* source, char* errorBuffer, size_t errorBufferCapacity, size_t* errorLength)
{
    Session* session = static_cast<Session*>(handle);

    if (!session || !chunkName || !source)
        return LUAUHOST_BAD_ARG;

    bool expected = false;
    if (!session->running.compare_exchange_strong(expected, true))
        return LUAUHOST_BUSY;

    session->cancel.store(false, std::memory_order_relaxed);
    session->outputBytes.store(0, std::memory_order_relaxed);
    session->outputTruncated.store(false, std::memory_order_relaxed);
    session->mem.budget = session->config.memoryLimitBytes;
    session->mem.used = 0;
    session->deadline = std::chrono::steady_clock::now() + std::chrono::duration_cast<std::chrono::steady_clock::duration>(std::chrono::duration<double>(session->config.timeLimitSeconds));

    t_session = session;

    int result = LUAUHOST_OK;
    std::string errorMessage;
    std::string truncatedNotice;
    lua_State* L = nullptr;

    // compile (no VM state needed; location info comes from the parser/compiler)
    Luau::CompileOptions options{};
    options.optimizationLevel = 1;
    options.debugLevel = 1;

    std::string bytecode;
    {
        Luau::Allocator allocator;
        Luau::AstNameTable names(allocator);
        Luau::ParseResult parseResult = Luau::Parser::parse(source, strlen(source), names, allocator, Luau::ParseOptions{});

        if (!parseResult.errors.empty())
        {
            errorMessage = formatParseError(chunkName, parseResult.errors.front());
            result = LUAUHOST_COMPILE_ERROR;
            goto finish;
        }

        try
        {
            Luau::BytecodeBuilder builder;
            Luau::compileOrThrow(builder, parseResult, names, options);
            bytecode = builder.getBytecode();
        }
        catch (const Luau::CompileError& error)
        {
            errorMessage = formatCompileError(chunkName, error);
            result = LUAUHOST_COMPILE_ERROR;
            goto finish;
        }
    }

    enableDefaultFlags();

    L = lua_newstate(luaAlloc, &session->mem);
    if (!L)
    {
        errorMessage = "failed to create the Luau VM state";
        result = LUAUHOST_RUNTIME_ERROR;
        goto finish;
    }

    luaL_openlibs(L);

    lua_pushcfunction(L, lf_print, "print");
    lua_setglobal(L, "print");

    lua_pushcfunction(L, lf_warn, "warn");
    lua_setglobal(L, "warn");

    if (session->config.enableLoadstring)
    {
        lua_pushcfunction(L, lf_loadstring, "loadstring");
        lua_setglobal(L, "loadstring");
    }

    if (session->config.enableHttpGet && session->config.onHttp)
    {
        lua_pushcfunction(L, lf_httpget, "http_get");
        lua_setglobal(L, "http_get");
    }

    luaL_sandbox(L);

    {
        lua_State* T = lua_newthread(L);
        luaL_sandboxthread(T);
        lua_callbacks(T)->interrupt = interrupt;

        std::string chunk = std::string("=") + (chunkName[0] != '\0' ? chunkName : "script");

        if (luau_load(T, chunk.c_str(), bytecode.data(), bytecode.size(), 0) != 0)
        {
            const char* message = lua_tolstring(T, -1, nullptr);
            errorMessage = message ? std::string("failed to load compiled bytecode: ") + message : std::string("failed to load compiled bytecode");
            result = LUAUHOST_RUNTIME_ERROR;
            goto finish;
        }

        lua_pushcfunction(T, errorHandler, "errorhandler");
        lua_insert(T, 1); // [handler, function]

        const int status = lua_pcall(T, 0, 0, 1);

        if (status != LUA_OK)
        {
            const char* message = lua_tolstring(T, -1, nullptr);
            errorMessage = message ? std::string(message) : std::string("unknown runtime error");
            result = mapPcallStatus(status, errorMessage);
        }
    }

finish:
    if (L)
        lua_close(L);

    if (session->outputTruncated.load(std::memory_order_relaxed) && result == LUAUHOST_OK)
        truncatedNotice = "[output truncated at maxOutputBytes limit]";

    t_session = nullptr;
    session->running.store(false, std::memory_order_relaxed);

    if (result != LUAUHOST_OK)
    {
        copyErrorMessage(errorMessage, errorBuffer, errorBufferCapacity, errorLength);
    }
    else if (!truncatedNotice.empty())
    {
        copyErrorMessage(truncatedNotice, errorBuffer, errorBufferCapacity, errorLength);
    }

    return result;
}

void luauhost_session_cancel(void* handle)
{
    Session* session = static_cast<Session*>(handle);
    if (session)
        session->cancel.store(true, std::memory_order_relaxed);
}

void luauhost_session_destroy(void* handle)
{
    Session* session = static_cast<Session*>(handle);
    delete session;
}

const char* luauhost_version(void)
{
    return kVersion;
}

void* luauhost_alloc(size_t size)
{
    return std::malloc(size);
}

void luauhost_free(void* pointer)
{
    std::free(pointer);
}

} // extern "C"
