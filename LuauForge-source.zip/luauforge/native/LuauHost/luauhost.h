// LuauHost.h - C API for embedding the official Luau runtime in a sandboxed host.
//
// LuauForge embeds Luau (https://github.com/luau-lang/luau, MIT licensed) and
// executes scripts inside a fresh, isolated VM state per run:
//
//   * compile errors are reported with file/line/column (official Luau compiler)
//   * every run gets a new sandboxed thread (globals cannot leak between runs)
//   * wall-clock execution limit enforced through the VM interrupt safepoint
//   * memory limit enforced through a budgeted lua_Alloc allocator
//   * print()/warn() are captured through a callback (channel 0 / channel 1)
//   * loadstring is optional (off by default)
//   * http_get is optional (off by default); the actual network request is
//     performed by the embedder through a callback so the sandbox itself has
//     no network access at any time
//   * the Luau standard library surface is the official sandboxed set
//     (coroutine, table, os[clock/date/time/difftime], string, math, debug,
//      utf8, bit32, buffer, vector) with all library tables frozen readonly
//
// All functions are plain C, safe to P/Invoke from .NET.

#ifndef LUAUHOST_H
#define LUAUHOST_H

#include <stddef.h>

#ifdef __cplusplus
extern "C" {
#endif

#ifdef _WIN32
#define LUAUHOST_EXPORT __declspec(dllexport)
#else
#define LUAUHOST_EXPORT __attribute__((visibility("default")))
#endif

// Result of luauhost_session_execute.
enum LuauHostStatus
{
    LUAUHOST_OK = 0,            // script ran to completion
    LUAUHOST_COMPILE_ERROR = 1, // Luau compiler rejected the source
    LUAUHOST_RUNTIME_ERROR = 2, // uncaught error() or VM error
    LUAUHOST_TIMEOUT = 3,       // wall-clock limit exceeded
    LUAUHOST_CANCELLED = 4,     // luauhost_session_cancel() was called
    LUAUHOST_MEMORY_LIMIT = 5,  // allocator budget exceeded
    LUAUHOST_BAD_ARG = 6,       // invalid arguments
    LUAUHOST_BUSY = 7           // another execute() is already running on this session
};

// Output channels passed to LuauHostConfig.onOutput.
enum LuauHostChannel
{
    LUAUHOST_CHANNEL_PRINT = 0, // print()
    LUAUHOST_CHANNEL_WARN = 1   // warn()
};

// Called for each print()/warn() chunk emitted by the running script.
// 'data' is only valid for the duration of the call.
typedef void (*LuauHostOutputFn)(void* context, int channel, const char* data, size_t length);

// Called when a sandboxed script invokes http_get(url).
// Return non-zero on success: *outBody must point to a buffer allocated with
// luauhost_alloc() (the host frees it with luauhost_free()).
// Return zero on failure: *outError points to a luauhost_alloc()-allocated,
// NUL-terminated message (also freed by the host).
// Both out parameters must be set to NULL by the callee before returning.
typedef int (*LuauHostHttpFn)(void* context, const char* url, char** outBody, size_t* outBodyLength, char** outError);

typedef struct LuauHostConfig
{
    double timeLimitSeconds;    // wall-clock limit per execute(); clamped to [0.1, 3600]
    size_t memoryLimitBytes;    // total VM memory budget; clamped to [1 MB, 4 GB]
    size_t maxOutputBytes;      // cap on captured print/warn bytes; 0 = unlimited
    int enableLoadstring;       // expose loadstring() to scripts (0/1)
    int enableHttpGet;          // expose http_get() to scripts (0/1)
    void* callbackContext;      // opaque pointer passed to both callbacks
    LuauHostOutputFn onOutput;  // optional; print/warn sink
    LuauHostHttpFn onHttp;      // optional; only used when enableHttpGet != 0
} LuauHostConfig;

// Creates a session with the given limits. Returns NULL on invalid config.
LUAUHOST_EXPORT void* luauhost_session_create(const LuauHostConfig* config);

// Compiles and runs 'source' in a fresh sandboxed VM state on the calling
// thread. This call blocks until the script finishes, fails, or hits a limit.
// On failure, a NUL-terminated UTF-8 message (including location info and, for
// runtime errors, a stack traceback) is written to errorBuffer and its length
// to *errorLength. errorBuffer/errorLength may be NULL/NULL to discard it.
// One execute at a time per session; concurrent calls return LUAUHOST_BUSY.
LUAUHOST_EXPORT int luauhost_session_execute(void* session, const char* chunkName, const char* source, char* errorBuffer, size_t errorBufferCapacity, size_t* errorLength);

// Requests cancellation of a running execute() on this session (safe to call
// from any thread). The VM aborts at its next interrupt safepoint with
// LUAUHOST_CANCELLED. A session may be reused after a cancelled run.
LUAUHOST_EXPORT void luauhost_session_cancel(void* session);

// Destroys a session. Must not be called while an execute() is running.
LUAUHOST_EXPORT void luauhost_session_destroy(void* session);

// Human-readable version string, e.g. "LuauHost 1.0.0 (Luau 0.746)".
LUAUHOST_EXPORT const char* luauhost_version(void);

// Allocator used for buffers crossing the native boundary (see LuauHostHttpFn).
LUAUHOST_EXPORT void* luauhost_alloc(size_t size);
LUAUHOST_EXPORT void luauhost_free(void* pointer);

#ifdef __cplusplus
} // extern "C"
#endif

#endif // LUAUHOST_H
