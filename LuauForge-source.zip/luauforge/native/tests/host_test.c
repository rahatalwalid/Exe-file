// host_test.c - sandbox conformance suite for LuauHost.
//
// Verifies every security and correctness guarantee of the sandbox against
// the real Luau runtime: print/warn capture, error reporting, time limits,
// memory limits, user cancellation, frozen libraries, fresh environments per
// run, gated loadstring/http_get, output caps, and stack-overflow containment.
//
// Build: native/CMakeLists.txt (Windows/CI) or scripts/build_native_test.sh (Linux).

#if !defined(_WIN32)
#define _POSIX_C_SOURCE 200809L
#endif

#include "luauhost.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#ifdef _WIN32
#include <windows.h>
#else
#include <pthread.h>
#include <time.h>
#include <unistd.h>
#endif

// ---------------------------------------------------------------------------
// Harness plumbing
// ---------------------------------------------------------------------------

#define PRINT_BUF_CAP 65536
#define WARN_BUF_CAP 8192

static char printBuf[PRINT_BUF_CAP];
static size_t printLen;
static char warnBuf[WARN_BUF_CAP];
static size_t warnLen;
static void* lastOutputContext;

static void resetOutput(void)
{
    printBuf[0] = '\0';
    warnBuf[0] = '\0';
    printLen = 0;
    warnLen = 0;
}

static void outputCallback(void* context, int channel, const char* data, size_t length)
{
    lastOutputContext = context;

    char* buffer = channel == LUAUHOST_CHANNEL_WARN ? warnBuf : printBuf;
    size_t* len = channel == LUAUHOST_CHANNEL_WARN ? &warnLen : &printLen;
    size_t cap = channel == LUAUHOST_CHANNEL_WARN ? WARN_BUF_CAP : PRINT_BUF_CAP;

    if (*len + length >= cap)
        length = cap - *len - 1;

    memcpy(buffer + *len, data, length);
    *len += length;
    buffer[*len] = '\0';
}

static int fakeHttpOk = 0;

static int httpCallback(void* context, const char* url, char** outBody, size_t* outBodyLength, char** outError)
{
    (void)context;
    (void)url;

    *outBody = NULL;
    *outBodyLength = 0;
    *outError = NULL;

    if (fakeHttpOk)
    {
        const char* body = "OK-DATA";
        char* copy = (char*)luauhost_alloc(strlen(body) + 1);
        memcpy(copy, body, strlen(body) + 1);
        *outBody = copy;
        *outBodyLength = strlen(body);
        return 1;
    }

    const char* errorText = "domain not in allowlist";
    char* copy = (char*)luauhost_alloc(strlen(errorText) + 1);
    memcpy(copy, errorText, strlen(errorText) + 1);
    *outError = copy;
    return 0;
}

static void* makeSession(double timeLimit, size_t memoryLimit, size_t outputCap, int loadstring, int http)
{
    LuauHostConfig config;
    memset(&config, 0, sizeof(config));
    config.timeLimitSeconds = timeLimit;
    config.memoryLimitBytes = memoryLimit;
    config.maxOutputBytes = outputCap;
    config.enableLoadstring = loadstring;
    config.enableHttpGet = http;
    config.callbackContext = (void*)0xCAFEBABE;
    config.onOutput = outputCallback;
    config.onHttp = httpCallback;
    return luauhost_session_create(&config);
}

static int runScript(void* session, const char* source, char* errorBuffer, size_t errorBufferCapacity)
{
    resetOutput();
    return luauhost_session_execute(session, "script", source, errorBuffer, errorBufferCapacity, NULL);
}

static const char* statusName(int status)
{
    switch (status)
    {
    case LUAUHOST_OK: return "OK";
    case LUAUHOST_COMPILE_ERROR: return "COMPILE_ERROR";
    case LUAUHOST_RUNTIME_ERROR: return "RUNTIME_ERROR";
    case LUAUHOST_TIMEOUT: return "TIMEOUT";
    case LUAUHOST_CANCELLED: return "CANCELLED";
    case LUAUHOST_MEMORY_LIMIT: return "MEMORY_LIMIT";
    case LUAUHOST_BAD_ARG: return "BAD_ARG";
    case LUAUHOST_BUSY: return "BUSY";
    default: return "UNKNOWN";
    }
}

#define CHECK_STATUS(status, expected) \
    CHECK_STATUS_IMPL(status, expected)

#define CHECK_STATUS_IMPL(status, expected)                                                                 \
    do                                                                                                     \
    {                                                                                                      \
        if ((status) == (expected))                                                                        \
        {                                                                                                  \
            g_pass++;                                                                                      \
        }                                                                                                  \
        else                                                                                               \
        {                                                                                                  \
            g_fail++;                                                                                      \
            printf("  FAIL %s:%d  status=%s expected=%s\n", __func__, __LINE__, statusName(status), statusName(expected)); \
        }                                                                                                  \
    } while (0)

static double monotonicSeconds(void)
{
#ifdef _WIN32
    return (double)GetTickCount64() / 1000.0;
#else
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return (double)ts.tv_sec + (double)ts.tv_nsec / 1e9;
#endif
}

static void sleepMs(int milliseconds)
{
#ifdef _WIN32
    Sleep((DWORD)milliseconds);
#else
    struct timespec request;
    request.tv_sec = milliseconds / 1000;
    request.tv_nsec = (long)(milliseconds % 1000) * 1000000L;
    nanosleep(&request, NULL);
#endif
}

typedef struct ThreadRun
{
    void* session;
    const char* source;
    int status;
    char error[2048];
} ThreadRun;

#ifdef _WIN32
static DWORD WINAPI threadExecute(LPVOID arg)
#else
static void* threadExecute(void* arg)
#endif
{
    ThreadRun* run = (ThreadRun*)arg;
    run->status = runScript(run->session, run->source, run->error, sizeof(run->error));
#ifndef _WIN32
    return NULL;
#endif
}

static int g_pass = 0;
static int g_fail = 0;

#define CHECK(cond)                                                                                                     \
    do                                                                                                                 \
    {                                                                                                                  \
        if (cond)                                                                                                      \
        {                                                                                                              \
            g_pass++;                                                                                                  \
        }                                                                                                              \
        else                                                                                                           \
        {                                                                                                              \
            g_fail++;                                                                                                  \
            printf("  FAIL %s:%d  (%s)\n", __func__, __LINE__, #cond);                                                 \
        }                                                                                                              \
    } while (0)

// ---------------------------------------------------------------------------
// Tests
// ---------------------------------------------------------------------------

static void test_version(void)
{
    const char* version = luauhost_version();
    CHECK(version != NULL && strstr(version, "Luau") != NULL);
}

static void test_hello_print(void)
{
    void* session = makeSession(2.0, 64 * 1024 * 1024, 0, 0, 0);
    char err[2048];
    int status = runScript(session, "print(\"hello, world\")", err, sizeof(err));
    CHECK_STATUS(status, LUAUHOST_OK);
    CHECK(strcmp(printBuf, "hello, world\n") == 0);
    CHECK(lastOutputContext == (void*)0xCAFEBABE);
    luauhost_session_destroy(session);
}

static void test_print_formatting(void)
{
    void* session = makeSession(2.0, 64 * 1024 * 1024, 0, 0, 0);
    char err[2048];
    int status = runScript(session, "print(1, 2.5, nil, true, \"str\")", err, sizeof(err));
    CHECK_STATUS(status, LUAUHOST_OK);
    CHECK(strcmp(printBuf, "1\t2.5\tnil\ttrue\tstr\n") == 0);
    luauhost_session_destroy(session);
}

static void test_warn_channel(void)
{
    void* session = makeSession(2.0, 64 * 1024 * 1024, 0, 0, 0);
    char err[2048];
    int status = runScript(session, "warn(\"careful\", 42)", err, sizeof(err));
    CHECK_STATUS(status, LUAUHOST_OK);
    CHECK(strcmp(warnBuf, "careful 42\n") == 0);
    CHECK(printLen == 0);
    luauhost_session_destroy(session);
}

static void test_runtime_error(void)
{
    void* session = makeSession(2.0, 64 * 1024 * 1024, 0, 0, 0);
    char err[2048];
    const char* source = "local function inner() error(\"boom\") end\nlocal function outer() inner() end\nouter()\n";
    int status = runScript(session, source, err, sizeof(err));
    CHECK_STATUS(status, LUAUHOST_RUNTIME_ERROR);
    CHECK(strstr(err, "script:1: boom") != NULL);
    CHECK(strstr(err, "function inner") != NULL);
    CHECK(strstr(err, "function outer") != NULL);
    luauhost_session_destroy(session);
}

static void test_error_location(void)
{
    void* session = makeSession(2.0, 64 * 1024 * 1024, 0, 0, 0);
    char err[2048];
    const char* source = "local x = nil\nx.y = 1\n";
    int status = runScript(session, source, err, sizeof(err));
    CHECK_STATUS(status, LUAUHOST_RUNTIME_ERROR);
    CHECK(strstr(err, "script:2") != NULL);
    CHECK(strstr(err, "attempt to index nil") != NULL);
    luauhost_session_destroy(session);
}

static void test_syntax_error(void)
{
    void* session = makeSession(2.0, 64 * 1024 * 1024, 0, 0, 0);
    char err[2048];
    int status = runScript(session, "local = 5\nprint(\"never\")", err, sizeof(err));
    CHECK_STATUS(status, LUAUHOST_COMPILE_ERROR);
    CHECK(strstr(err, "SyntaxError") != NULL);
    CHECK(strstr(err, "script(1,") != NULL);
    CHECK(printLen == 0); // nothing executed
    luauhost_session_destroy(session);
}

static void test_timeout(void)
{
    void* session = makeSession(0.1, 64 * 1024 * 1024, 0, 0, 0);
    char err[2048];
    double started = monotonicSeconds();
    int status = runScript(session, "while true do end", err, sizeof(err));
    double elapsed = monotonicSeconds() - started;
    CHECK_STATUS(status, LUAUHOST_TIMEOUT);
    CHECK(strstr(err, "timed out") != NULL);
    CHECK(elapsed < 10.0);
    luauhost_session_destroy(session);
}

static void test_memory_limit(void)
{
    void* session = makeSession(10.0, 8 * 1024 * 1024, 0, 0, 0);
    char err[2048];
    int status = runScript(session, "local t = {}\nwhile true do t[#t + 1] = string.rep(\"x\", 4096) end", err, sizeof(err));
    CHECK_STATUS(status, LUAUHOST_MEMORY_LIMIT);
    luauhost_session_destroy(session);
}

static void test_cancel(void)
{
    // Two concurrent runs, both cancelled from the outside; the VM must abort
    // promptly at its next interrupt safepoint with LUAUHOST_CANCELLED.
    void* sessionA = makeSession(30.0, 64 * 1024 * 1024, 0, 0, 0);
    void* sessionB = makeSession(30.0, 64 * 1024 * 1024, 0, 0, 0);

    ThreadRun runA, runB;
    memset(&runA, 0, sizeof(runA));
    memset(&runB, 0, sizeof(runB));
    runA.session = sessionA;
    runA.source = "while true do end";
    runB.session = sessionB;
    runB.source = "while true do end";

#ifdef _WIN32
    HANDLE threadA = CreateThread(NULL, 0, threadExecute, &runA, 0, NULL);
    HANDLE threadB = CreateThread(NULL, 0, threadExecute, &runB, 0, NULL);
#else
    pthread_t threadA, threadB;
    pthread_create(&threadA, NULL, threadExecute, &runA);
    pthread_create(&threadB, NULL, threadExecute, &runB);
#endif

    sleepMs(150);
    double cancelStart = monotonicSeconds();
    luauhost_session_cancel(sessionA);
    luauhost_session_cancel(sessionB);

#ifdef _WIN32
    WaitForSingleObject(threadA, 30000);
    WaitForSingleObject(threadB, 30000);
    CloseHandle(threadA);
    CloseHandle(threadB);
#else
    pthread_join(threadA, NULL);
    pthread_join(threadB, NULL);
#endif

    double cancelElapsed = monotonicSeconds() - cancelStart;

    CHECK(runA.status == LUAUHOST_CANCELLED);
    CHECK(runB.status == LUAUHOST_CANCELLED);
    CHECK(strstr(runA.error, "cancelled") != NULL);
    CHECK(cancelElapsed < 10.0);

    luauhost_session_destroy(sessionA);
    luauhost_session_destroy(sessionB);
}

static void test_busy(void)
{
    void* session = makeSession(30.0, 64 * 1024 * 1024, 0, 0, 0);

    ThreadRun run;
    memset(&run, 0, sizeof(run));
    run.session = session;
    run.source = "local t0 = os.clock()\nwhile os.clock() - t0 < 0.3 do end";

#ifdef _WIN32
    HANDLE thread = CreateThread(NULL, 0, threadExecute, &run, 0, NULL);
#else
    pthread_t thread;
    pthread_create(&thread, NULL, threadExecute, &run);
#endif

    sleepMs(80);
    char err[2048];
    int status = luauhost_session_execute(session, "script", "print(\"nope\")", err, sizeof(err), NULL);
    CHECK_STATUS(status, LUAUHOST_BUSY);

#ifdef _WIN32
    WaitForSingleObject(thread, 30000);
    CloseHandle(thread);
#else
    pthread_join(thread, NULL);
#endif

    CHECK(run.status == LUAUHOST_OK); // background run finished fine
    luauhost_session_destroy(session);
}

static void test_stdlib_surface(void)
{
    void* session = makeSession(2.0, 64 * 1024 * 1024, 0, 0, 0);
    char err[2048];
    const char* source =
        "assert(io == nil)\n"
        "assert(os.execute == nil)\n"
        "assert(os.getenv == nil)\n"
        "assert(type(os.time()) == \"number\")\n"
        "assert(type(os.clock()) == \"number\")\n"
        "assert(math.sqrt(4) == 2)\n"
        "assert(string.format(\"%d|%s\", 7, \"x\") == \"7|x\")\n"
        "assert(table.concat({1, 2, 3}, \"-\") == \"1-2-3\")\n"
        "assert(bit32.band(6, 3) == 2)\n"
        "assert(utf8.char(72, 105) == \"Hi\")\n"
        "assert(type(buffer.create(16)) == \"buffer\")\n"
        "assert(type(vector.create(1, 2, 3)) == \"vector\")\n"
        "local co = coroutine.wrap(function() coroutine.yield(1) return 2 end)\n"
        "assert(co() == 1 and co() == 2)\n"
        "assert(type(debug.traceback) == \"function\")\n"
        "print(\"stdlib-ok\")\n";
    int status = runScript(session, source, err, sizeof(err));
    CHECK_STATUS(status, LUAUHOST_OK);
    if (status != LUAUHOST_OK)
        printf("  stdlib error: %s\n", err);
    CHECK(strcmp(printBuf, "stdlib-ok\n") == 0);
    luauhost_session_destroy(session);
}

static void test_frozen_libraries(void)
{
    void* session = makeSession(2.0, 64 * 1024 * 1024, 0, 0, 0);
    char err[2048];
    const char* source =
        "local ok, err = pcall(function() string.format = function() end end)\n"
        "assert(not ok, \"string.format was writable\")\n"
        "assert(tostring(err):find(\"readonly\") ~= nil, \"expected readonly error, got \" .. tostring(err))\n"
        "print(\"frozen-ok\")\n";
    int status = runScript(session, source, err, sizeof(err));
    CHECK_STATUS(status, LUAUHOST_OK);
    if (status != LUAUHOST_OK)
        printf("  frozen error: %s\n", err);
    luauhost_session_destroy(session);
}

static void test_fresh_environment(void)
{
    void* session = makeSession(2.0, 64 * 1024 * 1024, 0, 0, 0);
    char err[2048];

    int status1 = runScript(session, "persistedGlobal = 42\nprint(\"set\")", err, sizeof(err));
    CHECK_STATUS(status1, LUAUHOST_OK);

    int status2 = runScript(session, "print(\"count=\", persistedGlobal)", err, sizeof(err));
    CHECK_STATUS(status2, LUAUHOST_OK);
    CHECK(strcmp(printBuf, "count=\tnil\n") == 0);

    luauhost_session_destroy(session);
}

static void test_loadstring_gated(void)
{
    void* session = makeSession(2.0, 64 * 1024 * 1024, 0, 0, 0);
    char err[2048];
    int status = runScript(session, "assert(loadstring == nil, \"loadstring leaked\")\nprint(\"gated-ok\")", err, sizeof(err));
    CHECK_STATUS(status, LUAUHOST_OK);
    luauhost_session_destroy(session);

    void* session2 = makeSession(2.0, 64 * 1024 * 1024, 0, 1, 0);
    resetOutput();
    const char* source =
        "local f = assert(loadstring(\"return 6 * 7\"))\n"
        "print(f())\n"
        "local g = assert(loadstring(\"return io\"))\n"
        "print(g())\n";
    status = luauhost_session_execute(session2, "script", source, err, sizeof(err), NULL);
    CHECK_STATUS(status, LUAUHOST_OK);
    if (status != LUAUHOST_OK)
        printf("  loadstring error: %s\n", err);
    CHECK(strstr(printBuf, "42\n") != NULL);
    CHECK(strstr(printBuf, "nil\n") != NULL);
    luauhost_session_destroy(session2);
}

static void test_http_gated(void)
{
    void* session = makeSession(2.0, 64 * 1024 * 1024, 0, 0, 0);
    char err[2048];
    int status = runScript(session, "assert(http_get == nil, \"http_get leaked\")\nprint(\"gated-ok\")", err, sizeof(err));
    CHECK_STATUS(status, LUAUHOST_OK);
    luauhost_session_destroy(session);

    // success path
    fakeHttpOk = 1;
    void* session2 = makeSession(5.0, 64 * 1024 * 1024, 0, 0, 1);
    resetOutput();
    status = runScript(session2, "print(http_get(\"https://example.com/data.lua\"))", err, sizeof(err));
    CHECK_STATUS(status, LUAUHOST_OK);
    CHECK(strstr(printBuf, "OK-DATA") != NULL);
    luauhost_session_destroy(session2);

    // failure path surfaces the embedder's error message
    fakeHttpOk = 0;
    void* session3 = makeSession(5.0, 64 * 1024 * 1024, 0, 0, 1);
    status = runScript(session3, "http_get(\"http://intranet.local/secret\")", err, sizeof(err));
    CHECK_STATUS(status, LUAUHOST_RUNTIME_ERROR);
    CHECK(strstr(err, "domain not in allowlist") != NULL);
    luauhost_session_destroy(session3);

    // scheme validation happens inside the sandbox
    fakeHttpOk = 1;
    void* session4 = makeSession(5.0, 64 * 1024 * 1024, 0, 0, 1);
    status = runScript(session4, "http_get(\"file:///etc/passwd\")", err, sizeof(err));
    CHECK_STATUS(status, LUAUHOST_RUNTIME_ERROR);
    CHECK(strstr(err, "http:// or https://") != NULL);
    luauhost_session_destroy(session4);
    fakeHttpOk = 0;
}

static void test_output_cap(void)
{
    void* session = makeSession(5.0, 64 * 1024 * 1024, 1000, 0, 0);
    char err[2048];
    int status = runScript(session, "for i = 1, 200 do print(string.rep(\"x\", 100)) end", err, sizeof(err));
    CHECK_STATUS(status, LUAUHOST_OK);
    CHECK(printLen == 1000); // exactly capped, no overflow
    CHECK(printBuf[999] == 'x');
    luauhost_session_destroy(session);
}

static void test_stack_overflow_caught(void)
{
    void* session = makeSession(2.0, 64 * 1024 * 1024, 0, 0, 0);
    char err[4096];
    int status = runScript(session, "local function f() return 1 + f() end\nf()", err, sizeof(err));
    CHECK_STATUS(status, LUAUHOST_RUNTIME_ERROR);
    CHECK(strstr(err, "stack overflow") != NULL);
    luauhost_session_destroy(session);
}

static void test_return_values_ignored(void)
{
    void* session = makeSession(2.0, 64 * 1024 * 1024, 0, 0, 0);
    char err[2048];
    int status = runScript(session, "return 123", err, sizeof(err));
    CHECK_STATUS(status, LUAUHOST_OK);
    CHECK(printLen == 0);
    luauhost_session_destroy(session);
}

static void test_session_reuse(void)
{
    void* session = makeSession(2.0, 64 * 1024 * 1024, 0, 0, 0);
    char err[2048];
    for (int i = 0; i < 3; ++i)
    {
        char source[64];
        snprintf(source, sizeof(source), "print(\"iter %d\")", i);
        int status = runScript(session, source, err, sizeof(err));
        CHECK_STATUS(status, LUAUHOST_OK);
        CHECK(strstr(printBuf, "iter") != NULL);
    }
    luauhost_session_destroy(session);
}

static void test_bad_arguments(void)
{
    char err[256];
    CHECK(luauhost_session_create(NULL) == NULL);

    LuauHostConfig config;
    memset(&config, 0, sizeof(config));
    CHECK(luauhost_session_create(&config) == NULL); // no time limit, no output callback

    void* session = makeSession(2.0, 64 * 1024 * 1024, 0, 0, 0);
    CHECK(luauhost_session_execute(NULL, "s", "x", err, sizeof(err), NULL) == LUAUHOST_BAD_ARG);
    CHECK(luauhost_session_execute(session, "s", NULL, err, sizeof(err), NULL) == LUAUHOST_BAD_ARG);
    luauhost_session_destroy(session);
}

int main(void)
{
    printf("LuauHost sandbox conformance suite\n");
    printf("version: %s\n\n", luauhost_version());

    test_version();
    test_hello_print();
    test_print_formatting();
    test_warn_channel();
    test_runtime_error();
    test_error_location();
    test_syntax_error();
    test_timeout();
    test_memory_limit();
    test_cancel();
    test_busy();
    test_stdlib_surface();
    test_frozen_libraries();
    test_fresh_environment();
    test_loadstring_gated();
    test_http_gated();
    test_output_cap();
    test_stack_overflow_caught();
    test_return_values_ignored();
    test_session_reuse();
    test_bad_arguments();

    printf("\n%d passed, %d failed\n", g_pass, g_fail);
    return g_fail > 0 ? 1 : 0;
}
