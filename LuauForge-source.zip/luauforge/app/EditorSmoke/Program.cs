// Headless smoke tests for the pure editor logic (LuauLexer + Completions).
// Runs on any OS; CI uses it to validate editor behavior without a GUI.

using LuauForge.Editor;

int failures = 0;

void Check(bool condition, string name)
{
    if (condition)
    {
        Console.WriteLine($"  PASS  {name}");
    }
    else
    {
        failures++;
        Console.WriteLine($"  FAIL  {name}");
    }
}

// Tokens with content (whitespace is lexed too, so filter it out for clarity).
List<LuauToken> Meaningful(string source) =>
    LuauLexer.Tokenize(source).Where(t => t.Kind != LuauTokenKind.Whitespace).ToList();

string KindAt(List<LuauToken> tokens, int index) =>
    index < tokens.Count ? tokens[index].Kind.ToString() : "<missing>";

// --- basic token classes -------------------------------------------------
{
    var tokens = Meaningful("local x = 42 -- greet\nprint(x)\n");
    Check(KindAt(tokens, 0) == "Keyword", "local is keyword");
    Check(KindAt(tokens, 1) == "Identifier", "x is identifier");
    Check(KindAt(tokens, 3) == "Number", "42 is number");
    Check(tokens.Any(t => t.Kind == LuauTokenKind.Comment), "line comment recognized");
    Check(tokens.Count == 9 && KindAt(tokens, 7) == "Identifier" && tokens[7].Start > tokens[5].Start, "second line parsed");
}

// --- strings -------------------------------------------------------------
{
    var tokens = Meaningful("\"hello \\\"world\\\"\" 'single' ");
    Check(tokens.Count == 2, $"two string tokens (got {tokens.Count})");
    Check(tokens.All(t => t.Kind == LuauTokenKind.Str), "short strings lexed");
}

{
    var tokens = Meaningful("[[long\nstring]] after");
    Check(tokens[0].Kind == LuauTokenKind.Str, "long string recognized");
    Check(tokens[0].Length == "[[long\nstring]]".Length, $"long string span ({tokens[0].Length})");
    Check(KindAt(tokens, 1) == "Identifier" && tokens[1].Start == "[[long\nstring]] ".Length, "text after long string");
}

{
    var tokens = Meaningful("[==[ nested ]] still long ]==] x");
    Check(tokens.Count == 2 && tokens[0].Kind == LuauTokenKind.Str, $"leveled long string not closed early (tokens: {tokens.Count})");
    Check(tokens[0].Length == "[==[ nested ]] still long ]==]".Length, $"leveled long string span ({tokens[0].Length})");
}

{
    var tokens = Meaningful("\"unterminated");
    Check(tokens[0].Kind == LuauTokenKind.Str && tokens[0].Length == "\"unterminated".Length, "unterminated string spans to EOL/EOF");
}

// --- comments ------------------------------------------------------------
{
    var tokens = Meaningful("--[[block\ncode()]] y = 1");
    Check(tokens[0].Kind == LuauTokenKind.Comment, "block comment recognized");
    Check(tokens[0].Length == "--[[block\ncode()]]".Length, "block comment span");
}

{
    var tokens = Meaningful("--[==[ deep ]==] z");
    Check(tokens[0].Kind == LuauTokenKind.Comment, "leveled block comment");
    Check(tokens[0].Start + tokens[0].Length == "--[==[ deep ]==]".Length, "leveled comment exact span");
    Check(KindAt(tokens, 1) == "Identifier" && tokens[1].Start == 17, "content after leveled comment");
}

// --- numbers -------------------------------------------------------------
{
    var tokens = Meaningful("0xFF 0b1010 1_000_000 1.5e-3 .5 10");
    Check(tokens.Count == 6, $"six numbers (got {tokens.Count}: {string.Join(',', tokens.Select(t => t.Kind))})");
    Check(tokens.All(t => t.Kind == LuauTokenKind.Number), "all numeric forms recognized");
    Check(tokens[0].Length == 4 && tokens[1].Length == 6 && tokens[2].Length == 9 && tokens[3].Length == 6, "numeric spans exact");
}

// --- operators -----------------------------------------------------------
{
    var tokens = Meaningful("a ..= b ... c == d ~= e :: f");
    var ops = tokens.Where(t => t.Kind == LuauTokenKind.Operator).ToList();
    Check(ops.Count == 5, $"five operators (got {ops.Count})");
    Check(ops[0].Length == 3 && ops[1].Length == 3, "compound assign and ellipsis are 3-char tokens");
}

// --- keywords and libraries ----------------------------------------------
{
    var tokens = Meaningful("while true do local function end string.format math.pi buffer.create");
    int keywords = tokens.Count(t => t.Kind == LuauTokenKind.Keyword);
    int libs = tokens.Count(t => t.Kind == LuauTokenKind.Library);
    Check(keywords == 6, $"six keywords (got {keywords})");
    Check(libs == 3, $"three libraries (got {libs})");
}

// --- contextual keywords -------------------------------------------------
{
    var tokens = Meaningful("type Foo = string export type Bar = number");
    Check(tokens.Count(t => t.Kind == LuauTokenKind.Keyword) == 3, "type/export highlighted as keywords");
}

// --- performance sanity --------------------------------------------------
{
    var sb = new System.Text.StringBuilder();
    for (int i = 0; i < 4000; i++)
        sb.AppendLine($"local value{i} = {i} -- iteration {i}\nprint(string.format(\"line %d\", value{i}))");
    string big = sb.ToString();

    var sw = System.Diagnostics.Stopwatch.StartNew();
    var tokens = LuauLexer.Tokenize(big);
    sw.Stop();

    Check(tokens.Count > 30000, $"tokenized {big.Length / 1024} KB into {tokens.Count} tokens");
    Check(sw.ElapsedMilliseconds < 3000, $"full relex in {sw.ElapsedMilliseconds} ms (< 3 s)");
}

// --- completions ---------------------------------------------------------
{
    var matches = Completions.ForPrefix("prin");
    Check(matches.Any(m => m.Insert == "print"), "prefix 'prin' suggests print");

    var members = Completions.MembersOf("string");
    Check(members.Any(m => m.Insert == "string.format(format, ...)"), "string.format completion");

    var tableMembers = Completions.MembersOf("table");
    Check(tableMembers.Any(m => m.Insert == "table.freeze(t)"), "table.freeze completion");

    Check(Completions.MembersOf("nosuchlib").Count == 0, "unknown library yields no members");

    var keywordMatch = Completions.ForPrefix("whi");
    Check(keywordMatch.Any(m => m.Category == "Keyword" && m.Insert == "while"), "keyword completion");

    var httpMatch = Completions.ForPrefix("http_g");
    Check(httpMatch.Any(m => m.Insert == "http_get"), "gated http_get is listed");

    Check(Completions.ForPrefix("q").Count == 0, "no bogus matches for single letters");
}

Console.WriteLine(failures == 0 ? "\nALL EDITOR TESTS PASSED" : $"\n{failures} FAILURES");
return failures == 0 ? 0 : 1;
