namespace LuauForge;

/// <summary>
/// Central dark theme: slate surfaces with an electric-blue accent.
/// All colors and fonts come from here so the UI stays consistent.
/// </summary>
public static class AppTheme
{
    // Surfaces
    public static readonly Color WindowBack = ColorTranslator.FromHtml("#1E2530");
    public static readonly Color PanelBack = ColorTranslator.FromHtml("#242D3A");
    public static readonly Color EditorBack = ColorTranslator.FromHtml("#161C26");
    public static readonly Color ConsoleBack = ColorTranslator.FromHtml("#11161E");
    public static readonly Color TabBack = ColorTranslator.FromHtml("#1A212C");
    public static readonly Color TabActive = ColorTranslator.FromHtml("#2F7BFF");

    // Content
    public static readonly Color Text = ColorTranslator.FromHtml("#D7DEE8");
    public static readonly Color TextMuted = ColorTranslator.FromHtml("#8A94A6");
    public static readonly Color Border = ColorTranslator.FromHtml("#313D4E");

    // Accents / status colors
    public static readonly Color Accent = ColorTranslator.FromHtml("#2F7BFF");
    public static readonly Color AccentHover = ColorTranslator.FromHtml("#4C90FF");
    public static readonly Color Warn = ColorTranslator.FromHtml("#E8B339");
    public static readonly Color Error = ColorTranslator.FromHtml("#E5534B");
    public static readonly Color Success = ColorTranslator.FromHtml("#3FB68B");
    public static readonly Color System = ColorTranslator.FromHtml("#9FB6D9");

    // Editor token colors
    public static readonly Color TokenKeyword = ColorTranslator.FromHtml("#5CA7FF");
    public static readonly Color TokenString = ColorTranslator.FromHtml("#D8A25D");
    public static readonly Color TokenNumber = ColorTranslator.FromHtml("#B48EFF");
    public static readonly Color TokenComment = ColorTranslator.FromHtml("#6C7A8C");
    public static readonly Color TokenBuiltin = ColorTranslator.FromHtml("#57C7A2");
    public static readonly Color TokenGlobal = ColorTranslator.FromHtml("#E8C57C");
    public static readonly Color TokenOperator = ColorTranslator.FromHtml("#98A7BC");

    public static Font UiFont { get; } = new("Segoe UI", 9f);
    public static Font UiFontBold { get; } = new("Segoe UI", 9f, FontStyle.Bold);
    public static Font TabFont { get; } = new("Segoe UI", 9f);
    public static Font ConsoleFont { get; } = CreateMonoFont(9f);

    public static Font CreateMonoFont(float size)
    {
        foreach (string name in new[] { "Cascadia Mono", "Cascadia Code", "Consolas", "Courier New" })
        {
            try
            {
                using (var probe = new Font(name, size))
                {
                    if (string.Equals(probe.FontFamily.Name, name, StringComparison.OrdinalIgnoreCase))
                        return new Font(name, size);
                }
            }
            catch
            {
                // fall through to next candidate
            }
        }

        return new Font(FontFamily.GenericMonospace, size);
    }

    /// <summary>Applies dark styling to any control tree (buttons, panels, etc.).</summary>
    public static void Apply(Control root)
    {
        foreach (Control control in root.Controls)
        {
            ApplyControl(control);
            Apply(control);
        }
    }

    private static void ApplyControl(Control control)
    {
        switch (control)
        {
            case Button button:
                button.FlatStyle = FlatStyle.Flat;
                button.FlatAppearance.BorderColor = Border;
                button.FlatAppearance.MouseOverBackColor = AccentHover;
                button.FlatAppearance.MouseDownBackColor = Accent;
                button.BackColor = PanelBack;
                button.ForeColor = Text;
                button.Font = UiFont;
                button.Height = Math.Max(button.Height, 26);
                break;
            case Label label:
                label.ForeColor = TextMuted;
                label.BackColor = Color.Transparent;
                break;
            case CheckBox checkBox:
                checkBox.ForeColor = Text;
                checkBox.BackColor = PanelBack;
                break;
            case NumericUpDown numeric:
                numeric.BackColor = EditorBack;
                numeric.ForeColor = Text;
                numeric.BorderStyle = BorderStyle.FixedSingle;
                break;
            case TextBox textBox:
                textBox.BackColor = EditorBack;
                textBox.ForeColor = Text;
                textBox.BorderStyle = BorderStyle.FixedSingle;
                break;
            case ComboBox combo:
                combo.BackColor = EditorBack;
                combo.ForeColor = Text;
                combo.FlatStyle = FlatStyle.Flat;
                break;
            case GroupBox groupBox:
                groupBox.ForeColor = Text;
                break;
        }
    }
}
