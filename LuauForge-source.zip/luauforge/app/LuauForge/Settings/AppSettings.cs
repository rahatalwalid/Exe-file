using System.Text.Json;
using System.Text.Json.Serialization;

namespace LuauForge.Settings;

/// <summary>
/// Persisted user settings (JSON at %APPDATA%\LuauForge\settings.json).
/// Security-relevant values (loadstring / http_get) default to OFF; the app
/// never enables them implicitly.
/// </summary>
public sealed class AppSettings
{
    public double TimeLimitSeconds { get; set; } = 10.0;
    public int MemoryLimitMb { get; set; } = 256;
    public int MaxOutputKb { get; set; } = 1024;
    public bool EnableLoadstring { get; set; } = false;
    public bool EnableHttpGet { get; set; } = false;
    public List<string> HttpAllowlist { get; set; } = new();
    public int EditorFontSize { get; set; } = 10;
    public bool WordWrap { get; set; } = false;
    public string LastOpenDir { get; set; } = string.Empty;
    public string WindowTitle { get; set; } = "LuauForge";

    [JsonIgnore]
    public static string StorePath { get; } = Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
        "LuauForge", "settings.json");

    private static readonly JsonSerializerOptions SerializerOptions = new()
    {
        WriteIndented = true,
        ReadCommentHandling = JsonCommentHandling.Skip,
        AllowTrailingCommas = true,
    };

    public static AppSettings Load()
    {
        try
        {
            if (File.Exists(StorePath))
            {
                string json = File.ReadAllText(StorePath);
                return JsonSerializer.Deserialize<AppSettings>(json, SerializerOptions) ?? new AppSettings();
            }
        }
        catch
        {
            // corrupt settings fall back to defaults rather than blocking startup
        }

        return new AppSettings();
    }

    public void Save()
    {
        try
        {
            Directory.CreateDirectory(Path.GetDirectoryName(StorePath)!);
            File.WriteAllText(StorePath, JsonSerializer.Serialize(this, SerializerOptions));
        }
        catch
        {
            // saving failures must not take the app down
        }
    }

    // Clamped views of the raw values; used when building native configs.
    public double ClampedTimeLimit => Math.Clamp(TimeLimitSeconds, 0.1, 3600.0);
    public int ClampedMemoryLimitMb => Math.Clamp(MemoryLimitMb, 1, 4096);
    public int ClampedMaxOutputKb => Math.Clamp(MaxOutputKb, 1, 64 * 1024);
    public int ClampedEditorFontSize => Math.Clamp(EditorFontSize, 8, 24);
}
