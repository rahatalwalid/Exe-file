using LuauForge.Editor;
using LuauForge.Native;
using LuauForge.Runtime;
using LuauForge.Settings;
using System.Text;

namespace LuauForge.UI;

/// <summary>
/// LuauForge main shell: toolbar, script tabs, editor, output console, status
/// bar. Owns the native sandbox session and all file/URL/script operations.
/// </summary>
public sealed class MainWindow : Form
{
    private AppSettings _settings;
    private LuauSession? _session;
    private bool _executing;

    private readonly TabControl _tabs;
    private readonly ConsoleView _console;
    private readonly ToolStripStatusLabel _statusLabel;
    private readonly ToolStripStatusLabel _caretLabel;
    private readonly ToolStripStatusLabel _versionLabel;
    private readonly ToolStripButton _executeButton;
    private readonly ToolStripButton _stopButton;
    private int _untitledCounter;

    public MainWindow(string[] args)
    {
        _settings = AppSettings.Load();

        Text = "LuauForge — Luau Sandbox Studio";
        BackColor = AppTheme.WindowBack;
        ForeColor = AppTheme.Text;
        Font = AppTheme.UiFont;
        StartPosition = FormStartPosition.CenterScreen;
        ClientSize = new Size(1280, 800);
        MinimumSize = new Size(920, 620);
        AllowDrop = true;
        KeyPreview = false;

        _console = new ConsoleView { Dock = DockStyle.Fill };
        _tabs = new TabControl
        {
            Dock = DockStyle.Fill,
            DrawMode = TabDrawMode.OwnerDrawFixed,
            ItemSize = new Size(160, 30),
            Padding = new Point(14, 6),
            BackColor = AppTheme.TabBack,
        };
        _tabs.DrawItem += OnDrawTab;
        _tabs.SelectedIndexChanged += (_, _) =>
        {
            UpdateStatus();
            CurrentEditor?.FocusEditor();
        };
        _tabs.MouseClick += OnTabClick;

        var editorHost = new Panel { Dock = DockStyle.Fill, BackColor = AppTheme.EditorBack };
        editorHost.Controls.Add(_tabs);

        var split = new SplitContainer
        {
            Dock = DockStyle.Fill,
            Orientation = Orientation.Horizontal,
            FixedPanel = FixedPanel.Panel2,
            SplitterWidth = 5,
            BackColor = AppTheme.Border,
        };
        split.Panel1.BackColor = AppTheme.EditorBack;
        split.Panel2.BackColor = AppTheme.ConsoleBack;
        split.Panel1.Controls.Add(editorHost);
        split.Panel2.Controls.Add(_console);
        split.SplitterDistance = 480;

        var statusBar = new StatusStrip
        {
            BackColor = AppTheme.PanelBack,
            SizingGrip = true,
        };
        _statusLabel = new ToolStripStatusLabel("Ready") { Spring = true, TextAlign = ContentAlignment.MiddleLeft, ForeColor = AppTheme.TextMuted };
        _caretLabel = new ToolStripStatusLabel("Ln 1, Col 1") { ForeColor = AppTheme.TextMuted };
        _versionLabel = new ToolStripStatusLabel(LuauSession.NativeVersion) { ForeColor = AppTheme.TextMuted };
        statusBar.Items.AddRange(new ToolStripItem[] { _statusLabel, _caretLabel, _versionLabel });

        BuildMenuBar();
        _executeButton = new ToolStripButton("Execute  (F5)") { ForeColor = AppTheme.Success, Font = AppTheme.UiFontBold, ToolTipText = "Run the current tab in the sandbox (F5)" };
        _executeButton.Click += (_, _) => RunCurrent();
        _stopButton = new ToolStripButton("Stop") { ForeColor = AppTheme.Text, Enabled = false, ToolTipText = "Cancel the running script" };
        _stopButton.Click += (_, _) => StopCurrent();
        ToolStrip menu = BuildMenuBar();
        ToolStrip toolbar = BuildToolbar();

        Controls.Add(split);
        Controls.Add(statusBar);
        Controls.Add(toolbar);
        Controls.Add(menu);

        // Dock layout processes children from the highest index down: menu and
        // toolbar claim their strips first, the split container fills the rest.
        Controls.SetChildIndex(split, 0);
        Controls.SetChildIndex(statusBar, 1);
        Controls.SetChildIndex(toolbar, 2);
        Controls.SetChildIndex(menu, 3);

        InitSession(announce: true);

        foreach (string path in args.Where(a => File.Exists(a)))
            OpenFile(path);

        if (_tabs.TabPages.Count == 0)
            NewTab();

        AppTheme.Apply(this);

        DragEnter += OnDragEnter;
        DragDrop += OnDragDrop;
        Shown += (_, _) => CurrentEditor?.FocusEditor();
    }

    // ------------------------------------------------------------------
    // Session
    // ------------------------------------------------------------------

    private void InitSession(bool announce)
    {
        if (_executing)
        {
            _console.AppendLine("[settings] changes apply after the current run finishes", AppTheme.System);
            return;
        }

        _session?.Dispose();
        _session = LuauSession.Create(_settings);

        if (_session is null)
        {
            _executeButton.Enabled = false;
            _statusLabel.Text = "LuauHost.dll not found — build the native module (see BUILDING.md)";
            if (announce)
            {
                MessageBox.Show(this,
                    "LuauHost.dll could not be loaded.\n\nPlace the compiled LuauHost.dll next to LuauForge.exe (or in the publish output).\nSee BUILDING.md for the native build steps.",
                    "LuauForge", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            return;
        }

        _session.Output += OnSessionOutput;
        _executeButton.Enabled = true;
        _statusLabel.Text = $"sandbox ready — limits: {_settings.ClampedTimeLimit:0.#}s / {_settings.ClampedMemoryLimitMb} MB / output cap {_settings.ClampedMaxOutputKb} KB";

        if (announce)
        {
            _console.AppendLine($"LuauForge ready — {LuauSession.NativeVersion}", AppTheme.System);
            _console.AppendLine("sandbox: isolated VM per run, time + memory limits enforced, filesystem and network unavailable.", AppTheme.System);
            _console.AppendLine($"features: loadstring {(_settings.EnableLoadstring ? "on" : "off")}, http_get {(_settings.EnableHttpGet ? "on" : "off (allowlist: " + _settings.HttpAllowlist.Count + " hosts)")}", AppTheme.System);
            _console.AppendLine("", AppTheme.System);
        }
    }

    private void OnSessionOutput(int channel, string text)
    {
        Color color = channel == LuauNative.ChannelWarn ? AppTheme.Warn : AppTheme.Text;
        BeginInvoke(() => _console.Append(text, color));
    }

    // ------------------------------------------------------------------
    // Menus and toolbar
    // ------------------------------------------------------------------

    private ToolStrip BuildMenuBar()
    {
        var menu = new MenuStrip
        {
            BackColor = AppTheme.PanelBack,
            ForeColor = AppTheme.Text,
            GripStyle = ToolStripGripStyle.Hidden,
            Padding = new Padding(4, 2, 4, 2),
        };

        var file = new ToolStripMenuItem("&File") { ForeColor = AppTheme.Text };
        file.DropDownItems.Add(new ToolStripMenuItem("&New tab", null, (_, _) => NewTab(), Keys.Control | Keys.N));
        file.DropDownItems.Add(new ToolStripMenuItem("&Open...", null, (_, _) => OpenDialog(), Keys.Control | Keys.O));
        file.DropDownItems.Add(new ToolStripMenuItem("&Save", null, (_, _) => SaveCurrent(), Keys.Control | Keys.S));
        file.DropDownItems.Add(new ToolStripMenuItem("Save &As...", null, (_, _) => SaveCurrentAs(), Keys.Control | Keys.Shift | Keys.S));
        file.DropDownItems.Add(new ToolStripMenuItem("Load &URL...", null, (_, _) => LoadUrl(), Keys.Control | Keys.U));
        file.DropDownItems.Add(new ToolStripSeparator());
        file.DropDownItems.Add(new ToolStripMenuItem("&Close tab", null, (_, _) => CloseCurrentTab(), Keys.Control | Keys.W));
        file.DropDownItems.Add(new ToolStripMenuItem("E&xit", null, (_, _) => Close(), Keys.Alt | Keys.F4));

        var run = new ToolStripMenuItem("&Run") { ForeColor = AppTheme.Text };
        run.DropDownItems.Add(new ToolStripMenuItem("&Execute", null, (_, _) => RunCurrent(), Keys.F5));
        run.DropDownItems.Add(new ToolStripMenuItem("&Stop", null, (_, _) => StopCurrent(), Keys.Control | Keys.F2));
        run.DropDownItems.Add(new ToolStripSeparator());
        run.DropDownItems.Add(new ToolStripMenuItem("Clear &console", null, (_, _) => _console.Clear(), Keys.Control | Keys.L));

        var settings = new ToolStripMenuItem("&Settings") { ForeColor = AppTheme.Text };
        settings.DropDownItems.Add(new ToolStripMenuItem("&Open settings...", null, (_, _) => ShowSettings(), Keys.Control | Keys.Oemcomma));

        var help = new ToolStripMenuItem("&Help") { ForeColor = AppTheme.Text };
        help.DropDownItems.Add(new ToolStripMenuItem("&About LuauForge", null, (_, _) => ShowAbout()));

        foreach (var item in new[] { file, run, settings, help })
        {
            item.DropDown.BackColor = AppTheme.PanelBack;
            item.DropDown.ForeColor = AppTheme.Text;
            item.DropDown.RenderMode = ToolStripRenderMode.Professional;
            item.DropDown.Renderer = new DarkRenderer();
            menu.Items.Add(item);
        }

        Controls.Add(menu);
        return menu;
    }

    private ToolStrip BuildToolbar()
    {
        var toolbar = new ToolStrip
        {
            GripStyle = ToolStripGripStyle.Hidden,
            BackColor = AppTheme.PanelBack,
            ForeColor = AppTheme.Text,
            RenderMode = ToolStripRenderMode.Professional,
            Renderer = new DarkRenderer(),
            Padding = new Padding(6, 2, 6, 2),
            Dock = DockStyle.Top,
        };

        _executeButton.ForeColor = AppTheme.Success;
        _executeButton.ToolTipText = "Run the current tab in the sandbox (F5)";
        _executeButton.Click += (_, _) => RunCurrent();

        _stopButton.ToolTipText = "Cancel the running script";
        _stopButton.Click += (_, _) => StopCurrent();

        var newButton = new ToolStripButton("New") { ForeColor = AppTheme.Text };
        newButton.Click += (_, _) => NewTab();
        var openButton = new ToolStripButton("Open") { ForeColor = AppTheme.Text };
        openButton.Click += (_, _) => OpenDialog();
        var saveButton = new ToolStripButton("Save") { ForeColor = AppTheme.Text };
        saveButton.Click += (_, _) => SaveCurrent();
        var urlButton = new ToolStripButton("Load URL") { ForeColor = AppTheme.Text };
        urlButton.Click += (_, _) => LoadUrl();
        var clearButton = new ToolStripButton("Clear console") { ForeColor = AppTheme.TextMuted };
        clearButton.Click += (_, _) => _console.Clear();
        var settingsButton = new ToolStripButton("Settings") { ForeColor = AppTheme.TextMuted };
        settingsButton.Click += (_, _) => ShowSettings();

        toolbar.Items.AddRange(new ToolStripItem[]
        {
            newButton, openButton, saveButton, urlButton,
            new ToolStripSeparator(),
            _executeButton, _stopButton,
            new ToolStripSeparator(),
            clearButton,
            new ToolStripSeparator(),
            settingsButton,
        });

        Controls.Add(toolbar);
        return toolbar;
    }

    private sealed class DarkRenderer : ToolStripProfessionalRenderer
    {
        public DarkRenderer() : base(new DarkColorTable()) { }
    }

    private sealed class DarkColorTable : ProfessionalColorTable
    {
        private Color Panel => AppTheme.PanelBack;
        private Color Hover => Color.FromArgb(45, 47, 123, 255);
        private Color Pressed => Color.FromArgb(70, 47, 123, 255);

        public override Color ToolStripGradientBegin => Panel;
        public override Color ToolStripGradientMiddle => Panel;
        public override Color ToolStripGradientEnd => Panel;
        public override Color ToolStripBorder => Panel;
        public override Color MenuStripGradientBegin => Panel;
        public override Color MenuStripGradientEnd => Panel;
        public override Color MenuItemSelected => Hover;
        public override Color MenuItemPressedGradientBegin => Pressed;
        public override Color MenuItemPressedGradientEnd => Pressed;
        public override Color MenuItemSelectedGradientBegin => Hover;
        public override Color MenuItemSelectedGradientEnd => Hover;
        public override Color MenuItemBorder => AppTheme.Border;
        public override Color ImageMarginGradientBegin => Panel;
        public override Color ImageMarginGradientMiddle => Panel;
        public override Color ImageMarginGradientEnd => Panel;
        public override Color SeparatorDark => AppTheme.Border;
        public override Color SeparatorLight => AppTheme.Border;
        public override Color ButtonSelectedGradientBegin => Hover;
        public override Color ButtonSelectedGradientEnd => Hover;
        public override Color ButtonPressedGradientBegin => Pressed;
        public override Color ButtonPressedGradientEnd => Pressed;
        public override Color ButtonSelectedBorder => AppTheme.Accent;
        public override Color CheckBackground => Hover;
        public override Color CheckSelectedBackground => Pressed;
    }

    // ------------------------------------------------------------------
    // Tabs
    // ------------------------------------------------------------------

    private ScriptTab? CurrentTab => _tabs.SelectedTab?.Tag as ScriptTab;

    private CodeEditor? CurrentEditor => CurrentTab?.Editor;

    private void NewTab(string path = "")
    {
        var editor = new CodeEditor
        {
            Dock = DockStyle.Fill,
        };
        editor.SetFontSize(_settings.ClampedEditorFontSize);
        editor.WordWrap = _settings.WordWrap;
        editor.ExecuteRequested += RunCurrent;
        editor.SaveRequested += () => SaveCurrent();
        editor.CaretMoved += (_, _) => UpdateStatus();
        editor.ModifiedChanged += UpdateCurrentTabTitle;

        var page = new TabPage
        {
            BackColor = AppTheme.EditorBack,
            ForeColor = AppTheme.Text,
            Padding = new Padding(0),
        };
        page.Controls.Add(editor);

        var tab = new ScriptTab { Editor = editor, FilePath = path, UntitledIndex = ++_untitledCounter };
        page.Tag = tab;

        if (path.Length > 0)
        {
            try
            {
                editor.EditorText = File.ReadAllText(path);
            }
            catch (Exception exception)
            {
                _console.AppendLine($"[open] failed to read {path}: {exception.Message}", AppTheme.Error);
            }
        }

        editor.MarkClean();
        page.Text = tab.Title;
        _tabs.TabPages.Add(page);
        _tabs.SelectedIndex = _tabs.TabPages.Count - 1;
        UpdateStatus();
        editor.FocusEditor();
    }

    private void UpdateCurrentTabTitle(object? sender, EventArgs e)
    {
        if (CurrentTab is { } tab && _tabs.SelectedTab is not null)
        {
            _tabs.SelectedTab.Text = tab.Title;
            UpdateStatus();
        }
    }

    private void OnDrawTab(object? sender, DrawItemEventArgs e)
    {
        TabPage page = _tabs.TabPages[e.Index];
        bool active = _tabs.SelectedIndex == e.Index;

        using var back = new SolidBrush(active ? AppTheme.TabBack : Color.FromArgb(28, 34, 44));
        e.Graphics.FillRectangle(back, e.Bounds);

        string title = page.Text;
        using var textBrush = new SolidBrush(active ? AppTheme.Text : AppTheme.TextMuted);
        TextRenderer.DrawText(e.Graphics, title, AppTheme.TabFont, new Point(e.Bounds.X + 12, e.Bounds.Y + 7), active ? AppTheme.Text : AppTheme.TextMuted);

        // accent underline on the active tab
        using var accent = new SolidBrush(AppTheme.Accent);
        e.Graphics.FillRectangle(accent, e.Bounds.X, e.Bounds.Bottom - 3, e.Bounds.Width, 3);

        // close glyph on the right
        TextRenderer.DrawText(e.Graphics, "×", AppTheme.TabFont,
            new Point(e.Bounds.Right - 24, e.Bounds.Y + 7), active ? AppTheme.TextMuted : AppTheme.Border);
    }

    private void OnTabClick(object? sender, MouseEventArgs e)
    {
        if (e.Button != MouseButtons.Middle && e.Button != MouseButtons.Right)
            return;

        for (int i = 0; i < _tabs.TabCount; i++)
        {
            Rectangle rect = _tabs.GetTabRect(i);
            if (!rect.Contains(e.Location))
                continue;

            if (e.Button == MouseButtons.Right)
            {
                _tabs.SelectedIndex = i;
                CloseCurrentTab();
            }
            else if (e.Button == MouseButtons.Middle)
            {
                _tabs.SelectedIndex = i;
                CloseCurrentTab();
            }
            return;
        }
    }

    private void CloseCurrentTab()
    {
        if (_tabs.SelectedTab is null)
            return;

        if (CurrentTab is { } tab && tab.Editor.Modified)
        {
            DialogResult choice = MessageBox.Show(this,
                $"'{tab.Title}' has unsaved changes. Save before closing?", "LuauForge",
                MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question);

            if (choice == DialogResult.Cancel)
                return;
            if (choice == DialogResult.Yes && !SaveCurrent())
                return;
        }

        int index = _tabs.SelectedIndex;
        _tabs.TabPages.RemoveAt(index);

        if (_tabs.TabPages.Count == 0)
            NewTab();
        else
            _tabs.SelectedIndex = Math.Min(index, _tabs.TabPages.Count - 1);
    }

    private void UpdateStatus()
    {
        var (line, column) = CurrentEditor?.CaretPosition ?? (1, 1);
        _caretLabel.Text = $"Ln {line}, Col {column}";
    }

    // ------------------------------------------------------------------
    // Files
    // ------------------------------------------------------------------

    private void OpenDialog()
    {
        using var dialog = new OpenFileDialog
        {
            Title = "Open Luau script",
            Filter = "Luau scripts (*.lua;*.luau)|*.lua;*.luau|All files (*.*)|*.*",
            InitialDirectory = _settings.LastOpenDir,
        };

        if (dialog.ShowDialog(this) == DialogResult.OK)
            OpenFile(dialog.FileName);
    }

    private void OpenFile(string path)
    {
        NewTab(Path.GetFullPath(path));
        _settings.LastOpenDir = Path.GetDirectoryName(Path.GetFullPath(path)) ?? _settings.LastOpenDir;
        _settings.Save();
    }

    private bool SaveCurrent() => CurrentTab is { } tab && (tab.IsUntitled ? SaveCurrentAs() : WriteTab(tab, tab.FilePath));

    private bool SaveCurrentAs()
    {
        if (CurrentTab is not { } tab)
            return false;

        using var dialog = new SaveFileDialog
        {
            Title = "Save Luau script",
            Filter = "Luau scripts (*.luau)|*.luau|Lua scripts (*.lua)|*.lua|All files (*.*)|*.*",
            FileName = tab.IsUntitled ? "script.luau" : Path.GetFileName(tab.FilePath),
            InitialDirectory = tab.IsUntitled
                ? (_settings.LastOpenDir.Length > 0 ? _settings.LastOpenDir : Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments))
                : Path.GetDirectoryName(tab.FilePath),
        };

        if (dialog.ShowDialog(this) != DialogResult.OK)
            return false;

        tab.FilePath = dialog.FileName;
        _settings.LastOpenDir = Path.GetDirectoryName(dialog.FileName) ?? _settings.LastOpenDir;
        _settings.Save();
        return WriteTab(tab, dialog.FileName);
    }

    private bool WriteTab(ScriptTab tab, string path)
    {
        try
        {
            File.WriteAllText(path, tab.Editor.EditorText, new UTF8Encoding(false));
            tab.Editor.MarkClean();
            if (_tabs.SelectedTab is not null)
                _tabs.SelectedTab.Text = tab.Title;
            _console.AppendLine($"[saved] {path}", AppTheme.Success);
            return true;
        }
        catch (Exception exception)
        {
            _console.AppendLine($"[save] failed: {exception.Message}", AppTheme.Error);
            MessageBox.Show(this, $"Could not save:\n{exception.Message}", "LuauForge", MessageBoxButtons.OK, MessageBoxIcon.Error);
            return false;
        }
    }

    // ------------------------------------------------------------------
    // URL loading (gated like the sandbox http_get)
    // ------------------------------------------------------------------

    private void LoadUrl()
    {
        if (!_settings.EnableHttpGet)
        {
            _console.AppendLine("[url] script loading by URL is disabled.", AppTheme.Warn);
            _console.AppendLine("[url] enable it in Settings (http_get) and add hosts to the allowlist, e.g. raw.githubusercontent.com", AppTheme.Warn);
            MessageBox.Show(this,
                "Loading scripts by URL is disabled.\n\nTo enable it: Settings > \"Expose http_get()\" and add allowed hosts (one per line).",
                "LuauForge", MessageBoxButtons.OK, MessageBoxIcon.Information);
            return;
        }

        using var prompt = new PromptForm("Load script from URL", "https://example.com/script.luau");
        if (prompt.ShowDialog(this) != DialogResult.OK || prompt.Value.Trim().Length == 0)
            return;

        string url = prompt.Value.Trim();
        var gate = new HttpGate(_settings.HttpAllowlist);
        string body = gate.TryFetch(url, out string bodyText, out string error) ? bodyText : string.Empty;

        if (body.Length == 0 && error.Length > 0)
        {
            _console.AppendLine($"[url] fetch failed: {error}", AppTheme.Error);
            return;
        }

        NewTab();
        if (CurrentEditor is not null)
        {
            CurrentEditor.EditorText = body;
            CurrentEditor.MarkClean();
            _console.AppendLine($"[url] loaded {url} ({body.Length} bytes) — review it, then press F5 to execute.", AppTheme.Success);
        }
    }

    private sealed class PromptForm : Form
    {
        public string Value => _input.Text;

        private readonly TextBox _input;

        public PromptForm(string title, string placeholder)
        {
            Text = title;
            BackColor = AppTheme.WindowBack;
            ForeColor = AppTheme.Text;
            Font = AppTheme.UiFont;
            FormBorderStyle = FormBorderStyle.FixedDialog;
            StartPosition = FormStartPosition.CenterParent;
            MinimizeBox = false;
            MaximizeBox = false;
            ClientSize = new Size(560, 110);

            _input = new TextBox { Dock = DockStyle.Top, Font = AppTheme.CreateMonoFont(10f), Text = placeholder, Padding = new Padding(4) };

            var ok = new Button { Text = "Load", DialogResult = DialogResult.OK, Width = 90, Height = 30, Left = 360, Top = 62 };
            ok.BackColor = AppTheme.Accent;
            ok.ForeColor = Color.White;
            var cancel = new Button { Text = "Cancel", DialogResult = DialogResult.Cancel, Width = 90, Height = 30, Left = 458, Top = 62 };

            AcceptButton = ok;
            CancelButton = cancel;

            Controls.Add(_input);
            Controls.Add(ok);
            Controls.Add(cancel);
            AppTheme.Apply(this);
        }
    }

    // ------------------------------------------------------------------
    // Execution
    // ------------------------------------------------------------------

    private async void RunCurrent()
    {
        if (_executing)
            return;

        if (CurrentTab is not { } tab || CurrentEditor is not { } editor)
            return;

        if (_session is null || !_session.IsReady)
        {
            MessageBox.Show(this, "The sandbox session is unavailable (LuauHost.dll missing).", "LuauForge",
                MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return;
        }

        string source = editor.EditorText;
        if (source.Trim().Length == 0)
            return;

        string chunkName = tab.IsUntitled ? $"Untitled{tab.UntitledIndex}" : Path.GetFileName(tab.FilePath);

        _executing = true;
        _executeButton.Enabled = false;
        _stopButton.Enabled = true;
        _statusLabel.Text = $"running {chunkName}...";
        _console.AppendLine($"── running {chunkName} ({source.Length} bytes) ──", AppTheme.System);

        LuauRunResult result = await _session.ExecuteAsync(chunkName, source);

        _executing = false;
        _executeButton.Enabled = true;
        _stopButton.Enabled = false;

        switch (result.Status)
        {
            case LuauRunStatus.Ok:
                if (result.Message.Length > 0)
                    _console.AppendLine(result.Message, AppTheme.System);
                _console.AppendLine($"── finished OK in {result.Duration.TotalMilliseconds:0} ms ──", AppTheme.Success);
                _statusLabel.Text = "finished OK";
                break;

            case LuauRunStatus.CompileError:
                _console.AppendLine("[syntax] " + result.Message, AppTheme.Error);
                _statusLabel.Text = "syntax error";
                break;

            case LuauRunStatus.RuntimeError:
                _console.AppendLine("[error] " + result.Message, AppTheme.Error);
                _statusLabel.Text = "runtime error";
                break;

            case LuauRunStatus.Timeout:
                _console.AppendLine("[limit] " + result.Message, AppTheme.Warn);
                _statusLabel.Text = "time limit hit";
                break;

            case LuauRunStatus.MemoryLimit:
                _console.AppendLine("[limit] " + result.Message, AppTheme.Warn);
                _statusLabel.Text = "memory limit hit";
                break;

            case LuauRunStatus.Cancelled:
                _console.AppendLine("[cancelled] execution cancelled by user", AppTheme.Warn);
                _statusLabel.Text = "cancelled";
                break;

            case LuauRunStatus.Busy:
                _console.AppendLine("[busy] another script is already running", AppTheme.Warn);
                break;

            default:
                _console.AppendLine("[error] " + result.Message, AppTheme.Error);
                break;
        }

        UpdateStatus();
    }

    private void StopCurrent() => _session?.Cancel();

    // ------------------------------------------------------------------
    // Settings / about
    // ------------------------------------------------------------------

    private void ShowSettings()
    {
        using var dialog = new SettingsDialog(_settings);
        if (dialog.ShowDialog(this) != DialogResult.OK || dialog.Copied is null)
            return;

        _settings = dialog.Copied;
        _settings.Save();

        foreach (TabPage page in _tabs.TabPages)
        {
            if (page.Tag is ScriptTab tab)
            {
                tab.Editor.SetFontSize(_settings.ClampedEditorFontSize);
                tab.Editor.WordWrap = _settings.WordWrap;
            }
        }

        InitSession(announce: false);
        _console.AppendLine($"[settings] applied — time {_settings.ClampedTimeLimit:0.#}s, memory {_settings.ClampedMemoryLimitMb} MB, loadstring {(_settings.EnableLoadstring ? "on" : "off")}, http_get {(_settings.EnableHttpGet ? "on" : "off")}", AppTheme.System);
    }

    private void ShowAbout()
    {
        MessageBox.Show(this,
            "LuauForge — Luau Sandbox Studio\n" +
            LuauSession.NativeVersion + "\n\n" +
            "A standalone Luau editor and sandboxed runtime for authorized\n" +
            "development and testing. Scripts run in an isolated official Luau VM\n" +
            "with time and memory limits — never inside any game or process.",
            "About LuauForge", MessageBoxButtons.OK, MessageBoxIcon.Information);
    }

    // ------------------------------------------------------------------
    // Drag & drop
    // ------------------------------------------------------------------

    private void OnDragEnter(object? sender, DragEventArgs e)
    {
        if (e.Data?.GetDataPresent(DataFormats.FileDrop) == true)
            e.Effect = DragDropEffects.Copy;
    }

    private void OnDragDrop(object? sender, DragEventArgs e)
    {
        if (e.Data?.GetData(DataFormats.FileDrop) is not string[] files)
            return;

        foreach (string file in files.Where(f => f.EndsWith(".lua", StringComparison.OrdinalIgnoreCase) || f.EndsWith(".luau", StringComparison.OrdinalIgnoreCase)))
            OpenFile(file);
    }
}
