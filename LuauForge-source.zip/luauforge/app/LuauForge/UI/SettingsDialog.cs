using LuauForge.Settings;

namespace LuauForge.UI;

/// <summary>
/// Settings dialog: sandbox limits, feature gates, allowlist, editor options.
/// OK applies and persists; Cancel discards.
/// </summary>
public sealed class SettingsDialog : Form
{
    private readonly AppSettings _working;

    private readonly NumericUpDown _timeLimit = new() { Minimum = 0.1m, Maximum = 3600m, DecimalPlaces = 1, Increment = 0.5m, Width = 120 };
    private readonly NumericUpDown _memoryLimit = new() { Minimum = 1, Maximum = 4096, Width = 120 };
    private readonly NumericUpDown _outputCap = new() { Minimum = 1, Maximum = 65536, Width = 120 };
    private readonly NumericUpDown _fontSize = new() { Minimum = 8, Maximum = 24, Width = 120 };
    private readonly CheckBox _enableLoadstring = new() { Text = "Expose loadstring() to scripts (off by default)", AutoSize = true };
    private readonly CheckBox _enableHttpGet = new() { Text = "Expose http_get() to scripts (off by default)", AutoSize = true };
    private readonly CheckBox _wordWrap = new() { Text = "Word wrap in editor", AutoSize = true };
    private readonly TextBox _allowlist = new() { Multiline = true, Height = 110, Dock = DockStyle.Fill, Font = AppTheme.CreateMonoFont(9f) };
    private readonly TextBox _hostField = new() { Dock = DockStyle.Fill };

    public SettingsDialog(AppSettings settings)
    {
        _working = new AppSettings
        {
            TimeLimitSeconds = settings.TimeLimitSeconds,
            MemoryLimitMb = settings.MemoryLimitMb,
            MaxOutputKb = settings.MaxOutputKb,
            EnableLoadstring = settings.EnableLoadstring,
            EnableHttpGet = settings.EnableHttpGet,
            HttpAllowlist = new List<string>(settings.HttpAllowlist),
            EditorFontSize = settings.EditorFontSize,
            WordWrap = settings.WordWrap,
            LastOpenDir = settings.LastOpenDir,
        };

        Text = "LuauForge Settings";
        BackColor = AppTheme.WindowBack;
        ForeColor = AppTheme.Text;
        Font = AppTheme.UiFont;
        StartPosition = FormStartPosition.CenterParent;
        FormBorderStyle = FormBorderStyle.FixedDialog;
        MaximizeBox = false;
        MinimizeBox = false;
        ClientSize = new Size(560, 520);

        var okButton = new Button { Text = "OK", DialogResult = DialogResult.OK, Width = 92, Height = 30 };
        var cancelButton = new Button { Text = "Cancel", DialogResult = DialogResult.Cancel, Width = 92, Height = 30 };
        okButton.BackColor = AppTheme.Accent;
        okButton.ForeColor = Color.White;
        okButton.FlatAppearance.BorderColor = AppTheme.Accent;

        okButton.Click += (_, _) =>
        {
            if (Apply())
            {
                DialogResult = DialogResult.OK;
                Close();
            }
        };
        cancelButton.Click += (_, _) =>
        {
            DialogResult = DialogResult.Cancel;
            Close();
        };

        AcceptButton = okButton;
        CancelButton = cancelButton;

        _timeLimit.Value = (decimal)_working.ClampedTimeLimit;
        _memoryLimit.Value = _working.ClampedMemoryLimitMb;
        _outputCap.Value = _working.ClampedMaxOutputKb;
        _fontSize.Value = _working.ClampedEditorFontSize;
        _enableLoadstring.Checked = _working.EnableLoadstring;
        _enableHttpGet.Checked = _working.EnableHttpGet;
        _wordWrap.Checked = _working.WordWrap;
        _allowlist.Text = string.Join("\r\n", _working.HttpAllowlist);
        _allowlist.ReadOnly = false;

        var layout = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            Padding = new Padding(16),
            ColumnCount = 2,
            RowCount = 12,
            AutoScroll = true,
        };
        layout.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 220));
        layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));

        int row = 0;
        AddHeader(layout, ref row, "Sandbox limits");
        AddRow(layout, ref row, "Time limit per run (seconds)", _timeLimit);
        AddRow(layout, ref row, "Memory limit per run (MB)", _memoryLimit);
        AddRow(layout, ref row, "Console capture cap (KB)", _outputCap);
        AddHeader(layout, ref row, "Sandbox features (all off by default)");
        AddRow(layout, ref row, "", _enableLoadstring);
        AddRow(layout, ref row, "", _enableHttpGet);
        AddHeader(layout, ref row, "http_get allowlist — one host per line, e.g. raw.githubusercontent.com; * = allow all");
        layout.Controls.Add(_allowlist, 1, row++);
        layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 118));
        AddHeader(layout, ref row, "Editor");
        AddRow(layout, ref row, "Editor font size (pt)", _fontSize);
        AddRow(layout, ref row, "", _wordWrap);

        var buttons = new FlowLayoutPanel
        {
            Dock = DockStyle.Bottom,
            FlowDirection = FlowDirection.RightToLeft,
            Padding = new Padding(16),
            Height = 56,
            BackColor = AppTheme.PanelBack,
        };
        buttons.Controls.Add(cancelButton);
        buttons.Controls.Add(okButton);

        Controls.Add(layout);
        Controls.Add(buttons);

        AppTheme.Apply(this);
        _enableLoadstring.ForeColor = AppTheme.Text;
        _enableHttpGet.ForeColor = AppTheme.Text;
        _wordWrap.ForeColor = AppTheme.Text;
    }

    private void AddHeader(TableLayoutPanel layout, ref int row, string text)
    {
        var label = new Label { Text = text, AutoSize = true, ForeColor = AppTheme.TextMuted, Margin = new Padding(0, row == 0 ? 0 : 10, 0, 4) };
        layout.Controls.Add(label, 0, row++);
        layout.SetColumnSpan(label, 2);
        layout.RowStyles.Add(new RowStyle(SizeType.AutoSize));
    }

    private void AddRow(TableLayoutPanel layout, ref int row, string label, Control control)
    {
        if (label.Length > 0)
        {
            layout.Controls.Add(new Label { Text = label, AutoSize = true, Anchor = AnchorStyles.Left, ForeColor = AppTheme.Text }, 0, row);
        }
        else
        {
            layout.Controls.Add(new Label { Text = "", AutoSize = true }, 0, row);
        }

        layout.Controls.Add(control, 1, row);
        layout.RowStyles.Add(new RowStyle(SizeType.Absolute, control is CheckBox ? 26 : 34));
        row++;
    }

    private bool Apply()
    {
        var allowlist = new List<string>();
        foreach (string line in _allowlist.Text.Split(['\r', '\n'], StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries))
        {
            allowlist.Add(line);
            if (line != "*" && line.StartsWith("*.") == false && line.Contains("://"))
            {
                MessageBox.Show(this, $"Allowlist entries should be plain hostnames (e.g. example.com or *.example.com).\nInvalid entry: {line}",
                    "LuauForge", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }
        }

        _working.TimeLimitSeconds = (double)_timeLimit.Value;
        _working.MemoryLimitMb = (int)_memoryLimit.Value;
        _working.MaxOutputKb = (int)_outputCap.Value;
        _working.EditorFontSize = (int)_fontSize.Value;
        _working.EnableLoadstring = _enableLoadstring.Checked;
        _working.EnableHttpGet = _enableHttpGet.Checked;
        _working.WordWrap = _wordWrap.Checked;
        _working.HttpAllowlist = allowlist;

        Copied = _working;
        return true;
    }

    /// <summary>The settings produced by the last successful Apply().</summary>
    public AppSettings? Copied { get; private set; }
}
