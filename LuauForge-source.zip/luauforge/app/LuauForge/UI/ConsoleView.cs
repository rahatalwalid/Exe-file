namespace LuauForge.UI;

/// <summary>
/// Colored output console (print/warn/errors/system notices). Append must be
/// called on the UI thread; MainWindow marshals native output onto it.
/// </summary>
public sealed class ConsoleView : UserControl
{
    private const int CapBytes = 1 * 1024 * 1024; // keep the RTB bounded

    private readonly RichTextBox _box;

    public ConsoleView()
    {
        _box = new RichTextBox
        {
            Dock = DockStyle.Fill,
            BorderStyle = BorderStyle.None,
            BackColor = AppTheme.ConsoleBack,
            ForeColor = AppTheme.Text,
            Font = AppTheme.ConsoleFont,
            ReadOnly = true,
            WordWrap = true,
            DetectUrls = false,
            HideSelection = false,
            ShortcutsEnabled = true,
        };

        Controls.Add(_box);
    }

    public void Append(string text, Color color)
    {
        if (text.Length == 0)
            return;

        _box.SelectionStart = _box.TextLength;
        _box.SelectionLength = 0;
        _box.SelectionColor = color;
        _box.AppendText(text);

        TrimIfNeeded();
        _box.SelectionStart = _box.TextLength;
        _box.SelectionLength = 0;
        _box.ScrollToCaret();
    }

    public void AppendLine(string text, Color color) => Append(text + "\n", color);

    public void Clear() => _box.Clear();

    private void TrimIfNeeded()
    {
        if (_box.TextLength <= CapBytes)
            return;

        int remove = _box.TextLength / 2;
        _box.Select(0, remove);
        _box.SelectedText = string.Empty;
        _box.SelectionStart = _box.TextLength;
    }
}
