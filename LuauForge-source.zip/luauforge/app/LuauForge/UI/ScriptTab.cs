using LuauForge.Editor;

namespace LuauForge.UI;

/// <summary>State for one editor tab (document + file path + dirty flag).</summary>
public sealed class ScriptTab
{
    public required CodeEditor Editor { get; init; }
    public string FilePath { get; set; } = string.Empty;
    public int UntitledIndex { get; init; }

    public bool IsUntitled => FilePath.Length == 0;

    public string Title
    {
        get
        {
            if (IsUntitled)
                return $"Untitled {UntitledIndex}" + (Editor.Modified ? " *" : "");
            return Path.GetFileName(FilePath) + (Editor.Modified ? " *" : "");
        }
    }
}
