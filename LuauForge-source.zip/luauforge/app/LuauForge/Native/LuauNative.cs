using System.Runtime.InteropServices;
using System.Text;

namespace LuauForge.Native;

/// <summary>
/// P/Invoke bindings for LuauHost.dll. All strings cross the boundary as
/// UTF-8 byte buffers (Luau source code is byte-oriented), never as ANSI
/// marshaled strings, so non-ASCII scripts survive the trip intact.
/// </summary>
internal static class LuauNative
{
    public const string LibraryName = "LuauHost";

    // Mirrors enum LuauHostStatus in luauhost.h
    public enum Status
    {
        Ok = 0,
        CompileError = 1,
        RuntimeError = 2,
        Timeout = 3,
        Cancelled = 4,
        MemoryLimit = 5,
        BadArg = 6,
        Busy = 7
    }

    public const int ChannelPrint = 0;
    public const int ChannelWarn = 1;

    public delegate void OutputFn(IntPtr context, int channel, IntPtr data, UIntPtr length);
    public delegate int HttpFn(IntPtr context, IntPtr url, out IntPtr body, out UIntPtr bodyLength, out IntPtr error);

    [StructLayout(LayoutKind.Sequential)]
    public struct LuauHostConfig
    {
        public double TimeLimitSeconds;
        public UIntPtr MemoryLimitBytes;
        public UIntPtr MaxOutputBytes;
        public int EnableLoadstring;
        public int EnableHttpGet;
        public IntPtr CallbackContext;
        public IntPtr OnOutput;
        public IntPtr OnHttp;
    }

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    public static extern IntPtr luauhost_session_create(ref LuauHostConfig config);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    public static extern int luauhost_session_execute(
        IntPtr session,
        byte[] chunkName,
        byte[] source,
        byte[] errorBuffer,
        UIntPtr errorBufferCapacity,
        out UIntPtr errorLength);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    public static extern void luauhost_session_cancel(IntPtr session);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    public static extern void luauhost_session_destroy(IntPtr session);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    public static extern IntPtr luauhost_version();

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    public static extern IntPtr luauhost_alloc(UIntPtr size);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    public static extern void luauhost_free(IntPtr pointer);

    public static string VersionString() => Marshal.PtrToStringUTF8(luauhost_version()) ?? "LuauHost";

    public static string PtrToStringUtf8(IntPtr pointer, UIntPtr length)
    {
        if (pointer == IntPtr.Zero || length == UIntPtr.Zero)
            return string.Empty;

        var buffer = new byte[(long)length];
        Marshal.Copy(pointer, buffer, 0, buffer.Length);
        return Encoding.UTF8.GetString(buffer);
    }

    public static string PtrToStringUtf8(IntPtr pointer)
    {
        if (pointer == IntPtr.Zero)
            return string.Empty;
        return Marshal.PtrToStringUTF8(pointer) ?? string.Empty;
    }

    /// <summary>Encodes a string as NUL-terminated UTF-8 for native calls.</summary>
    public static byte[] ToUtf8Z(string value)
    {
        var bytes = new byte[Encoding.UTF8.GetByteCount(value) + 1];
        Encoding.UTF8.GetBytes(value, 0, value.Length, bytes, 0);
        return bytes; // trailing zero is the NUL terminator
    }
}
