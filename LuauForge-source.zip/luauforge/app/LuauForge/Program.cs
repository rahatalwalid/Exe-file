namespace LuauForge;

internal static class Program
{
    [STAThread]
    private static void Main(string[] args)
    {
        // DPI awareness comes from app.manifest (PerMonitorV2); no runtime
        // SetHighDpiMode call to avoid conflicting with it.
        Application.EnableVisualStyles();
        Application.SetCompatibleTextRenderingDefault(false);

        AppDomain.CurrentDomain.UnhandledException += (_, e) =>
        {
            try
            {
                string path = Path.Combine(
                    Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
                    "LuauForge", "crash.log");
                File.AppendAllText(path, $"{DateTime.Now:u}\n{e.ExceptionObject}\n\n");
            }
            catch
            {
                // never let crash logging itself crash the process
            }
        };

        Application.Run(new UI.MainWindow(args));
    }
}
