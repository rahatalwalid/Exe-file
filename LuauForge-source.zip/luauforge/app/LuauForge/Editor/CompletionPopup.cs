namespace LuauForge.Editor;

/// <summary>
/// Auto-complete popup: a dark ListBox hosted in a borderless ToolStripDropDown.
/// The popup never owns keyboard focus; the editor intercepts navigation keys
/// and drives this class, so typing continues seamlessly.
/// </summary>
public sealed class CompletionPopup : ToolStripDropDown
{
    private const int ItemHeight = 20;

    private readonly ListBox _listBox;
    private List<CompletionItem> _filtered = new();

    public event Action<CompletionItem>? Committed;

    public CompletionPopup()
    {
        AutoClose = false;
        AutoSize = false;
        DropShadowEnabled = true;
        DoubleBuffered = true;
        CanOverflow = true;
        Padding = Padding.Empty;

        _listBox = new ListBox
        {
            BorderStyle = BorderStyle.None,
            DrawMode = DrawMode.OwnerDrawFixed,
            IntegralHeight = false,
            ItemHeight = ItemHeight,
            Font = AppTheme.CreateMonoFont(9f),
            BackColor = AppTheme.EditorBack,
            ForeColor = AppTheme.Text,
        };
        _listBox.DrawItem += OnDrawItem;

        var host = new ToolStripControlHost(_listBox)
        {
            AutoSize = false,
            Margin = Padding.Empty,
            Padding = Padding.Empty,
        };
        Items.Add(host);
    }

    public bool IsVisible => Visible;

    private static Color CategoryColor(string category) => category switch
    {
        "Keyword" => AppTheme.TokenKeyword,
        "Library" => AppTheme.TokenBuiltin,
        _ => AppTheme.TokenGlobal,
    };

    private void OnDrawItem(object? sender, DrawItemEventArgs e)
    {
        if (e.Index < 0 || e.Index >= _filtered.Count)
            return;

        CompletionItem item = _filtered[e.Index];
        Graphics g = e.Graphics;
        bool selected = (e.State & DrawItemState.Selected) != 0;

        using var back = new SolidBrush(selected ? Color.FromArgb(60, 47, 123, 255) : AppTheme.EditorBack);
        g.FillRectangle(back, e.Bounds);

        using var signatureBrush = new SolidBrush(CategoryColor(item.Category));
        g.DrawString(item.Signature, e.Font ?? Font, signatureBrush, e.Bounds.X + 6, e.Bounds.Y + 2);
    }

    public void ShowCompletions(string prefix, IReadOnlyList<CompletionItem> items, Point screenPoint)
    {
        _filtered = items.Where(i => i.Insert.StartsWith(prefix, StringComparison.OrdinalIgnoreCase) || i.Insert.Contains(prefix, StringComparison.OrdinalIgnoreCase))
            .OrderBy(i => !i.Insert.StartsWith(prefix, StringComparison.OrdinalIgnoreCase))
            .ThenBy(i => i.Insert, StringComparer.OrdinalIgnoreCase)
            .ToList();

        if (_filtered.Count == 0)
        {
            Hide();
            return;
        }

        _listBox.BeginUpdate();
        _listBox.Items.Clear();
        foreach (CompletionItem item in _filtered)
            _listBox.Items.Add(item);
        _listBox.EndUpdate();

        if (_listBox.Items.Count > 0)
            _listBox.SelectedIndex = 0;

        int width = Math.Max(360, Math.Min(560, 8 + _filtered.Max(i => TextRenderer.MeasureText(i.Signature, _listBox.Font).Width)));
        int height = Math.Min(7, _filtered.Count) * ItemHeight + 8;

        Location = screenPoint;
        Size = new Size(width, height);

        if (!Visible)
            Show();

        // Keep keyboard focus in the editor; the editor drives navigation.
        _listBox.SelectedIndex = _listBox.SelectedIndex;
    }

    public void HidePopup() => Visible = false;

    /// <summary>
    /// Handles a key while the popup is open. Returns true when the key was
    /// consumed (the editor should suppress it).
    /// </summary>
    public bool HandleKey(Keys keyData)
    {
        if (!Visible)
            return false;

        switch (keyData)
        {
            case Keys.Up:
                if (_listBox.SelectedIndex > 0)
                    _listBox.SelectedIndex--;
                return true;
            case Keys.Down:
                if (_listBox.SelectedIndex < _listBox.Items.Count - 1)
                    _listBox.SelectedIndex++;
                return true;
            case Keys.PageUp:
                _listBox.SelectedIndex = Math.Max(0, _listBox.SelectedIndex - 7);
                return true;
            case Keys.PageDown:
                _listBox.SelectedIndex = Math.Min(_listBox.Items.Count - 1, _listBox.SelectedIndex + 7);
                return true;
            case Keys.Home:
                _listBox.SelectedIndex = 0;
                return true;
            case Keys.End:
                _listBox.SelectedIndex = _listBox.Items.Count - 1;
                return true;
            case Keys.Enter:
            case Keys.Tab:
                if (_listBox.SelectedItem is CompletionItem item)
                    Committed?.Invoke(item);
                Hide();
                return true;
            case Keys.Escape:
                Hide();
                return true;
            default:
                return false;
        }
    }

    protected override void OnClosed(ToolStripDropDownClosedEventArgs e)
    {
        base.OnClosed(e);
    }
}
