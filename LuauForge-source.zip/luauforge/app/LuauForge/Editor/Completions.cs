namespace LuauForge.Editor;

public sealed record CompletionItem(string Signature, string Insert, string Category, string Doc)
{
    public override string ToString() => Signature;
}

/// <summary>
/// Static completion database for the editor. Everything listed here is part
/// of the official Luau standard library surface the sandbox actually exposes
/// (verified against Luau 0.746); nothing Roblox-specific is invented.
/// loadstring/http_get are marked as settings-gated.
/// </summary>
public static class Completions
{
    private static readonly (string Signature, string Doc)[] KeywordEntries =
    {
        ("local", "declare a local variable"),
        ("function", "declare a function"),
        ("if", "conditional"),
        ("elseif", "alternative condition branch"),
        ("else", "fallback condition branch"),
        ("then", "condition body start"),
        ("end", "close a block"),
        ("for", "numeric or generic for loop"),
        ("while", "while loop"),
        ("repeat", "repeat-until loop"),
        ("until", "repeat loop condition"),
        ("do", "block"),
        ("return", "return values from a function"),
        ("break", "exit a loop"),
        ("continue", "skip to the next loop iteration"),
        ("in", "generic for iterator clause"),
        ("and", "logical and (short-circuit)"),
        ("or", "logical or (short-circuit)"),
        ("not", "logical not"),
        ("nil", "the empty value"),
        ("true", "boolean true"),
        ("false", "boolean false"),
        ("type", "type alias declaration (Luau types)"),
        ("export", "export a type from a module"),
    };

    private static readonly (string Signature, string Doc)[] GlobalEntries =
    {
        ("print(...)", "print values to the output console (tab separated)"),
        ("warn(...)", "print values as warnings (orange console output)"),
        ("error(message, level?)", "raise an error; level 0 = no position, 1 = here, 2 = caller"),
        ("assert(condition, message?)", "throw an error if condition is false or nil"),
        ("pcall(fn, ...)", "call fn protected; returns ok, result-or-error"),
        ("xpcall(fn, handler, ...)", "call fn protected with an error handler"),
        ("tostring(value)", "convert any value to a string"),
        ("tonumber(value, base?)", "convert to a number or nil"),
        ("ipairs(t)", "iterate array part of a table (1..n)"),
        ("pairs(t)", "iterate all key/value pairs of a table"),
        ("next(t, key?)", "next key/value pair in a table"),
        ("select(index, ...)", "count args (with \"#\") or return args past index"),
        ("rawget(t, key)", "raw table read bypassing metatables"),
        ("rawset(t, key, value)", "raw table write bypassing metatables"),
        ("rawequal(a, b)", "raw equality bypassing metatables"),
        ("rawlen(t)", "raw length of a table or string"),
        ("setmetatable(t, mt)", "set a table's metatable"),
        ("getmetatable(t)", "read a table's metatable"),
        ("typeof(value)", "type name of a value (nil, number, string, table, ...)"),
        ("unpack(t)", "return array elements of a table as separate values"),
        ("_G", "the global environment table"),
        ("self", "implicit first argument of method calls"),
        ("loadstring(source, chunkname?)", "compile Lua source into a function [gated: settings > loadstring]"),
        ("http_get(url)", "fetch a URL as text [gated: settings > http_get + allowlist]"),
    };

    private static readonly Dictionary<string, (string Signature, string Doc)[]> LibraryMembers = new(StringComparer.Ordinal)
    {
        ["string"] = new[]
        {
            ("string.format(format, ...)", "printf-style formatting"),
            ("string.byte(s, i?, j?)", "byte values of characters"),
            ("string.char(...)", "string from byte values"),
            ("string.find(s, pattern, init?, plain?)", "find a pattern; returns start, end, captures"),
            ("string.gmatch(s, pattern)", "iterator over pattern matches"),
            ("string.gsub(s, pattern, repl, n?)", "substitute matches; returns new string, count"),
            ("string.match(s, pattern, init?)", "first pattern match or captures"),
            ("string.len(s)", "length in bytes"),
            ("string.lower(s)", "lowercase copy"),
            ("string.upper(s)", "uppercase copy"),
            ("string.rep(s, n, sep?)", "repeat a string n times"),
            ("string.reverse(s)", "reverse a string"),
            ("string.split(s, separator?)", "split into an array of substrings"),
            ("string.sub(s, i, j?)", "substring"),
        },
        ["table"] = new[]
        {
            ("table.insert(t, value)", "append a value"),
            ("table.insert(t, pos, value)", "insert a value at position"),
            ("table.remove(t, pos?)", "remove and return element at position"),
            ("table.concat(t, sep?, i?, j?)", "concatenate array elements"),
            ("table.sort(t, comparator?)", "sort in place"),
            ("table.pack(...)", "pack arguments into a table with n"),
            ("table.unpack(t, i?, j?)", "unpack array elements as separate values"),
            ("table.clone(t)", "shallow copy of a table"),
            ("table.clear(t)", "remove all keys"),
            ("table.freeze(t)", "make a table read-only"),
            ("table.isfrozen(t)", "check whether a table is frozen"),
            ("table.move(a1, f, e, t, a2?)", "move a slice of array values"),
            ("table.find(t, value, init?)", "find a value in the array part"),
            ("table.create(count, value?)", "preallocate an array"),
        },
        ["math"] = new[]
        {
            ("math.abs(x)", "absolute value"),
            ("math.acos(x)", "arc cosine"),
            ("math.asin(x)", "arc sine"),
            ("math.atan(x, y?)", "arc tangent"),
            ("math.atan2(y, x)", "arc tangent of y/x"),
            ("math.ceil(x)", "round up"),
            ("math.clamp(x, min, max)", "clamp to a range"),
            ("math.cos(x)", "cosine"),
            ("math.cosh(x)", "hyperbolic cosine"),
            ("math.deg(x)", "radians to degrees"),
            ("math.exp(x)", "e^x"),
            ("math.floor(x)", "round down"),
            ("math.fmod(x, y)", "remainder"),
            ("math.huge", "positive infinity"),
            ("math.log(x, base?)", "natural or base-b logarithm"),
            ("math.log10(x)", "base-10 logarithm"),
            ("math.max(...)", "largest argument"),
            ("math.min(...)", "smallest argument"),
            ("math.modf(x)", "integral and fractional parts"),
            ("math.pi", "the constant pi"),
            ("math.rad(x)", "degrees to radians"),
            ("math.random(m?, n?)", "random number"),
            ("math.randomseed(seed)", "seed the RNG"),
            ("math.sign(x)", "-1, 0, or 1"),
            ("math.sin(x)", "sine"),
            ("math.sinh(x)", "hyperbolic sine"),
            ("math.sqrt(x)", "square root"),
            ("math.tan(x)", "tangent"),
            ("math.tanh(x)", "hyperbolic tangent"),
        },
        ["os"] = new[]
        {
            ("os.clock()", "CPU time used by the process, in seconds"),
            ("os.date(format?, time?)", "formatted date/time"),
            ("os.difftime(t2, t1?)", "difference between times"),
            ("os.time(t?)", "current epoch time"),
        },
        ["coroutine"] = new[]
        {
            ("coroutine.create(fn)", "create a coroutine"),
            ("coroutine.resume(co, ...)", "run or continue a coroutine"),
            ("coroutine.yield(...)", "suspend the coroutine"),
            ("coroutine.status(co)", "\"suspended\", \"running\", \"normal\", or \"dead\""),
            ("coroutine.wrap(fn)", "wrap a coroutine body into a function"),
            ("coroutine.running()", "the running coroutine, or nil"),
            ("coroutine.close(co)", "close a coroutine"),
            ("coroutine.isyieldable()", "can the current thread yield"),
        },
        ["bit32"] = new[]
        {
            ("bit32.band(...)", "bitwise and"),
            ("bit32.bor(...)", "bitwise or"),
            ("bit32.bxor(...)", "bitwise exclusive or"),
            ("bit32.bnot(x)", "bitwise not"),
            ("bit32.btest(...)", "test bits (returns boolean)"),
            ("bit32.lshift(x, n)", "left shift"),
            ("bit32.rshift(x, n)", "right shift"),
            ("bit32.arshift(x, n)", "arithmetic right shift"),
            ("bit32.lrotate(x, n)", "left rotate"),
            ("bit32.rrotate(x, n)", "right rotate"),
            ("bit32.extract(n, field, width?)", "extract a bit field"),
            ("bit32.replace(n, value, field, width?)", "replace a bit field"),
            ("bit32.countlz(n)", "count leading zeros"),
            ("bit32.countrz(n)", "count trailing zeros"),
            ("bit32.byteswap(n)", "swap byte order"),
        },
        ["utf8"] = new[]
        {
            ("utf8.char(...)", "string from codepoints"),
            ("utf8.code(s, i?)", "codepoint at byte position"),
            ("utf8.codes(s)", "iterate (position, codepoint) pairs"),
            ("utf8.len(s, i?, j?)", "length in codepoints"),
            ("utf8.offset(s, n, i?)", "byte offset of the n-th codepoint"),
            ("utf8.graphemes(s)", "iterate grapheme clusters"),
            ("utf8.nfcnormalize(s)", "NFC normalization"),
            ("utf8.nfdnormalize(s)", "NFD normalization"),
            ("utf8.charpattern", "pattern matching one UTF-8 sequence"),
        },
        ["buffer"] = new[]
        {
            ("buffer.create(size)", "create a byte buffer"),
            ("buffer.fromstring(s)", "buffer from a byte string"),
            ("buffer.tostring(b)", "byte string from a buffer"),
            ("buffer.len(b)", "buffer length"),
            ("buffer.readstring(b, offset, count)", "read bytes into a string"),
            ("buffer.writestring(b, offset, s)", "write a byte string"),
            ("buffer.readi8(b, offset)", "read a signed 8-bit integer"),
            ("buffer.readu8(b, offset)", "read an unsigned 8-bit integer"),
            ("buffer.readi16(b, offset)", "read a signed little-endian 16-bit integer"),
            ("buffer.readu16(b, offset)", "read an unsigned little-endian 16-bit integer"),
            ("buffer.readi32(b, offset)", "read a signed little-endian 32-bit integer"),
            ("buffer.readu32(b, offset)", "read an unsigned little-endian 32-bit integer"),
            ("buffer.readf32(b, offset)", "read a little-endian float"),
            ("buffer.readf64(b, offset)", "read a little-endian double"),
            ("buffer.writei8(b, offset, value)", "write a signed 8-bit integer"),
            ("buffer.writeu8(b, offset, value)", "write an unsigned 8-bit integer"),
            ("buffer.writei16(b, offset, value)", "write a 16-bit integer"),
            ("buffer.writei32(b, offset, value)", "write a 32-bit integer"),
            ("buffer.writef32(b, offset, value)", "write a float"),
            ("buffer.writef64(b, offset, value)", "write a double"),
        },
        ["vector"] = new[]
        {
            ("vector.create(x, y, z)", "create a 3D vector"),
            ("vector.magnitude(v)", "length of a vector"),
            ("vector.dot(a, b)", "dot product"),
            ("vector.cross(a, b)", "cross product"),
            ("vector.normalize(v)", "unit vector"),
            ("vector.zero", "the zero vector"),
        },
        ["debug"] = new[]
        {
            ("debug.info(options)", "information about a function or stack level"),
            ("debug.traceback(message?, level?)", "string describing the call stack"),
        },
    };

    private static readonly Lazy<List<CompletionItem>> AllItems = new(BuildAll);

    private static List<CompletionItem> BuildAll()
    {
        var items = new List<CompletionItem>(256);

        foreach (var (signature, doc) in KeywordEntries)
            items.Add(new CompletionItem(signature, FirstWord(signature), "Keyword", doc));

        foreach (var (signature, doc) in GlobalEntries)
            items.Add(new CompletionItem(signature, FirstWord(signature), "Global", doc));

        foreach (var (library, members) in LibraryMembers)
        {
            foreach (var (signature, doc) in members)
                items.Add(new CompletionItem(signature, signature, "Library", doc));
        }

        return items;
    }

    private static string FirstWord(string signature)
    {
        int paren = signature.IndexOf('(');
        return paren >= 0 ? signature[..paren] : signature;
    }

    /// <summary>Members of a known library (for "string." style triggers).</summary>
    public static IReadOnlyList<CompletionItem> MembersOf(string library)
    {
        if (LibraryMembers.TryGetValue(library, out var members))
        {
            return members.Select(m => new CompletionItem(m.Signature, m.Signature, "Library", m.Doc)).ToList();
        }
        return Array.Empty<CompletionItem>();
    }

    /// <summary>Word completions for an identifier prefix, best matches first.</summary>
    public static IReadOnlyList<CompletionItem> ForPrefix(string prefix)
    {
        if (prefix.Length == 0)
            return Array.Empty<CompletionItem>();

        // Contain-style matches are only useful once the prefix is specific
        // enough; for 1-2 chars, prefix matches alone stay relevant.
        bool allowContains = prefix.Length >= 3;

        var matches = new List<CompletionItem>();
        foreach (CompletionItem item in AllItems.Value)
        {
            if (item.Insert.StartsWith(prefix, StringComparison.OrdinalIgnoreCase) && item.Insert.Length != prefix.Length)
                matches.Add(item);
        }

        if (allowContains)
        {
            var seen = new HashSet<CompletionItem>(matches);
            foreach (CompletionItem item in AllItems.Value)
            {
                if (!seen.Contains(item) &&
                    item.Insert.Contains(prefix, StringComparison.OrdinalIgnoreCase) &&
                    item.Insert.Length != prefix.Length)
                    matches.Add(item);
            }
        }

        return matches
            .OrderBy(m => !m.Insert.StartsWith(prefix, StringComparison.OrdinalIgnoreCase))
            .ThenBy(m => m.Insert, StringComparer.OrdinalIgnoreCase)
            .Take(30)
            .ToList();
    }

    public static IReadOnlyList<CompletionItem> All => AllItems.Value;
}
