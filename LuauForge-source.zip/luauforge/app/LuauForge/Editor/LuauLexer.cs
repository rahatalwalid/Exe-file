namespace LuauForge.Editor;

public enum LuauTokenKind
{
    Whitespace,
    Identifier,
    Keyword,
    Library,   // stdlib namespaces: string, table, math, ...
    Global,    // built-in global functions: print, warn, ...
    Number,
    Str,
    Comment,
    Operator,
}

public readonly record struct LuauToken(int Start, int Length, LuauTokenKind Kind);

/// <summary>
/// Single-pass Luau tokenizer for editor highlighting. Handles line and block
/// comments (-- and --[[ ]=] with nesting levels), short and long strings,
/// decimal/hex/binary/exponent numbers, and Luau's contextual keywords.
/// Performance target: full-file relex of a few thousand lines in well under
/// a frame budget on a mid-range laptop.
/// </summary>
public static class LuauLexer
{
    public static readonly string[] Keywords =
    {
        "and", "break", "continue", "do", "else", "elseif", "end", "false", "for",
        "function", "if", "in", "local", "nil", "not", "or", "repeat", "return",
        "then", "true", "until", "while", "export", "type",
    };

    public static readonly string[] Libraries =
    {
        "bit32", "buffer", "coroutine", "debug", "integer", "math", "os",
        "string", "table", "utf8", "vector",
    };

    public static readonly string[] Globals =
    {
        "_G", "assert", "error", "getmetatable", "http_get", "ipairs", "loadstring",
        "next", "pairs", "pcall", "print", "rawequal", "rawget", "rawlen", "rawset",
        "require", "select", "self", "setmetatable", "tostring", "tonumber", "typeof",
        "unpack", "warn", "xpcall",
    };

    private static readonly HashSet<string> KeywordSet = new(Keywords);
    private static readonly HashSet<string> LibrarySet = new(Libraries);
    private static readonly HashSet<string> GlobalSet = new(Globals);

    public static bool IsKeyword(string word) => KeywordSet.Contains(word);

    public static List<LuauToken> Tokenize(string source)
    {
        var tokens = new List<LuauToken>(source.Length / 6 + 16);
        int n = source.Length;
        int i = 0;

        while (i < n)
        {
            char c = source[i];

            if (c == ' ' || c == '\t' || c == '\r' || c == '\n')
            {
                int start = i;
                while (i < n && (source[i] == ' ' || source[i] == '\t' || source[i] == '\r' || source[i] == '\n'))
                    i++;
                tokens.Add(new LuauToken(start, i - start, LuauTokenKind.Whitespace));
                continue;
            }

            if (char.IsLetter(c) || c == '_')
            {
                int start = i;
                while (i < n && (char.IsLetterOrDigit(source[i]) || source[i] == '_'))
                    i++;
                tokens.Add(new LuauToken(start, i - start, ClassifyWord(source, start, i)));
                continue;
            }

            if (char.IsDigit(c))
            {
                int end = ScanNumber(source, i);
                tokens.Add(new LuauToken(i, end - i, LuauTokenKind.Number));
                i = end;
                continue;
            }

            if (c == '"' || c == '\'')
            {
                int end = ScanShortString(source, i);
                tokens.Add(new LuauToken(i, end - i, LuauTokenKind.Str));
                i = end;
                continue;
            }

            if (c == '[' && i + 1 < n)
            {
                int level = LongBracketLevel(source, i);
                if (level >= 0)
                {
                    int end = ScanLongBracket(source, i, level);
                    tokens.Add(new LuauToken(i, end - i, LuauTokenKind.Str));
                    i = end;
                    continue;
                }
            }

            if (c == '-' && i + 1 < n && source[i + 1] == '-')
            {
                int start = i;
                i += 2;
                int level = i < n && source[i] == '[' ? LongBracketLevel(source, i) : -1;
                if (level >= 0)
                {
                    i = ScanLongBracket(source, i, level);
                }
                else
                {
                    while (i < n && source[i] != '\n')
                        i++;
                }
                tokens.Add(new LuauToken(start, i - start, LuauTokenKind.Comment));
                continue;
            }

            if (c == '.' && i + 1 < n && char.IsDigit(source[i + 1]))
            {
                int end = ScanNumber(source, i);
                tokens.Add(new LuauToken(i, end - i, LuauTokenKind.Number));
                i = end;
                continue;
            }

            int opEnd = ScanOperator(source, i);
            tokens.Add(new LuauToken(i, opEnd - i, LuauTokenKind.Operator));
            i = opEnd;
        }

        return tokens;
    }

    private static LuauTokenKind ClassifyWord(string source, int start, int end)
    {
        int length = end - start;
        string word = source.Substring(start, length);
        if (KeywordSet.Contains(word))
            return LuauTokenKind.Keyword;
        if (LibrarySet.Contains(word))
            return LuauTokenKind.Library;
        if (GlobalSet.Contains(word))
            return LuauTokenKind.Global;
        return LuauTokenKind.Identifier;
    }

    /// <summary>Number of '=' inside "[=...[" at position i, or -1 if not a long bracket opener.</summary>
    private static int LongBracketLevel(string source, int i)
    {
        int n = source.Length;
        if (i >= n || source[i] != '[')
            return -1;

        int j = i + 1;
        while (j < n && source[j] == '=')
            j++;

        if (j < n && source[j] == '[')
            return j - i - 1;
        return -1;
    }

    private static int ScanLongBracket(string source, int start, int level)
    {
        int n = source.Length;
        int i = start + level + 2; // skip opening [==[
        while (i < n)
        {
            if (source[i] == ']')
            {
                int j = i + 1;
                while (j < n && j - i - 1 < level && source[j] == '=')
                    j++;
                if (j - i - 1 == level && j < n && source[j] == ']')
                    return j + 1;
            }
            i++;
        }
        return n; // unterminated long string/comment extends to EOF
    }

    private static int ScanShortString(string source, int start)
    {
        int n = source.Length;
        char quote = source[start];
        int i = start + 1;

        while (i < n)
        {
            char c = source[i];
            if (c == '\\' && i + 1 < n)
            {
                i += 2; // skip escaped char (covers \n, \", \\, \65, \xHH prefix, etc.)
                continue;
            }
            if (c == quote)
                return i + 1;
            if (c == '\n')
                return i; // unterminated string stops at end of line
            i++;
        }
        return n;
    }

    private static int ScanNumber(string source, int start)
    {
        int n = source.Length;
        int i = start;

        if (source[i] == '0' && i + 1 < n && (source[i + 1] == 'x' || source[i + 1] == 'X'))
        {
            i += 2;
            while (i < n && (Uri.IsHexDigit(source[i]) || source[i] == '_'))
                i++;
            return i;
        }

        if (source[i] == '0' && i + 1 < n && (source[i + 1] == 'b' || source[i + 1] == 'B'))
        {
            i += 2;
            while (i < n && (source[i] == '0' || source[i] == '1' || source[i] == '_'))
                i++;
            return i;
        }

        while (i < n && (char.IsDigit(source[i]) || source[i] == '_'))
            i++;

        if (i < n && source[i] == '.')
        {
            i++;
            while (i < n && (char.IsDigit(source[i]) || source[i] == '_'))
                i++;
        }

        if (i < n && (source[i] == 'e' || source[i] == 'E'))
        {
            int lookahead = i + 1;
            if (lookahead < n && (source[lookahead] == '+' || source[lookahead] == '-'))
                lookahead++;
            if (lookahead < n && char.IsDigit(source[lookahead]))
            {
                i = lookahead;
                while (i < n && (char.IsDigit(source[i]) || source[i] == '_'))
                    i++;
            }
        }

        return i;
    }

    private static int ScanOperator(string source, int start)
    {
        int n = source.Length;

        if (start + 3 <= n)
        {
            string three = source.Substring(start, 3);
            if (three == "..." || three == "..=")
                return start + 3;
        }

        if (start + 2 <= n)
        {
            string two = source.Substring(start, 2);
            switch (two)
            {
                case "==":
                case "~=":
                case "<=":
                case ">=":
                case "..":
                case "::":
                case "+=":
                case "-=":
                case "*=":
                case "/=":
                case "%=":
                case "^=":
                    return start + 2;
            }
        }

        return start + 1;
    }
}
