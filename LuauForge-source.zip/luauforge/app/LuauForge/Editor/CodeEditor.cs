using System.Runtime.InteropServices;

namespace LuauForge.Editor;

/// <summary>
/// Custom zero-dependency Luau code editor: RichTextBox core with owner-drawn
/// line-number gutter, debounced syntax highlighting, auto-indent, block
/// indent/outdent, and popup autocomplete. No third-party editor controls.
/// </summary>
public sealed class CodeEditor : UserControl
{
    private const int WmUser = 0x0400;
    private const int EmGetScrollPos = WmUser + 221;
    private const int EmSetScrollPos = WmUser + 222;
    private const int WmSetRedraw = 0x000B;
    private const string Indent = "    ";

    [StructLayout(LayoutKind.Sequential)]
    private struct NativePoint
    {
        public int X;
        public int Y;
    }

    private readonly RichTextBox _textBox;
    private readonly Panel _gutter;
    private readonly System.Windows.Forms.Timer _highlightTimer;
    private readonly CompletionPopup _popup;
    private bool _suppressEvents;
    private bool _modified;
    private string _contextWord = string.Empty;

    /// <summary>Raised when the document's modified state changes.</summary>
    public event EventHandler? ModifiedChanged;

    /// <summary>Raised whenever the caret or selection moves.</summary>
    public event EventHandler? CaretMoved;

    /// <summary>Raised on F5 — run the current script.</summary>
    public event Action? ExecuteRequested;

    /// <summary>Raised on Ctrl+S — save the current script.</summary>
    public event Action? SaveRequested;

    public CodeEditor()
    {
        DoubleBuffered = true;

        _gutter = new Panel
        {
            Dock = DockStyle.Left,
            Width = 46,
            BackColor = AppTheme.TabBack,
        };
        _gutter.Paint += OnGutterPaint;

        _textBox = new RichTextBox
        {
            Dock = DockStyle.Fill,
            BorderStyle = BorderStyle.None,
            BackColor = AppTheme.EditorBack,
            ForeColor = AppTheme.Text,
            Font = AppTheme.CreateMonoFont(10f),
            Multiline = true,
            WordWrap = false,
            AcceptsTab = true,
            DetectUrls = false,
            HideSelection = false,
            ScrollBars = RichTextBoxScrollBars.Both,
            ShowSelectionMargin = false,
        };
        _textBox.TextChanged += OnTextChanged;
        _textBox.KeyDown += OnKeyDown;
        _textBox.KeyPress += OnKeyPress;
        _textBox.VScroll += (_, _) => _gutter.Invalidate();
        _textBox.SelectionChanged += OnSelectionChanged;

        _highlightTimer = new System.Windows.Forms.Timer { Interval = 220 };
        _highlightTimer.Tick += (_, _) =>
        {
            _highlightTimer.Stop();
            Highlight();
            UpdateCompletion();
        };

        _popup = new CompletionPopup();
        _popup.Committed += OnCompletionCommitted;

        Controls.Add(_textBox);
        Controls.Add(_gutter);
    }

    // ------------------------------------------------------------------
    // Public surface
    // ------------------------------------------------------------------

    public string EditorText
    {
        get => _textBox.Text;
        set
        {
            _suppressEvents = true;
            _textBox.Text = value;
            _textBox.SelectionStart = 0;
            _modified = false;
            _suppressEvents = false;
            Highlight();
            _gutter.Invalidate();
        }
    }

    public bool Modified
    {
        get => _modified;
        private set
        {
            if (_modified != value)
            {
                _modified = value;
                ModifiedChanged?.Invoke(this, EventArgs.Empty);
            }
        }
    }

    public bool WordWrap
    {
        get => _textBox.WordWrap;
        set
        {
            _textBox.WordWrap = value;
            Highlight();
        }
    }

    public (int Line, int Column) CaretPosition
    {
        get
        {
            int line = _textBox.GetLineFromCharIndex(_textBox.SelectionStart);
            int lineStart = _textBox.GetFirstCharIndexFromLine(line);
            return (line + 1, _textBox.SelectionStart - lineStart + 1);
        }
    }

    public void SetFontSize(int pointSize)
    {
        _textBox.Font = AppTheme.CreateMonoFont(pointSize);
        _gutter.Invalidate();
    }

    public void GoToLine(int lineNumber)
    {
        int index = _textBox.GetFirstCharIndexFromLine(Math.Max(0, lineNumber - 1));
        if (index >= 0)
        {
            _textBox.SelectionStart = index;
            _textBox.SelectionLength = 0;
            _textBox.ScrollToCaret();
            _textBox.Focus();
        }
    }

    public void FocusEditor() => _textBox.Focus();

    public void MarkClean() => Modified = false;

    protected override void Dispose(bool disposing)
    {
        if (disposing)
        {
            _highlightTimer.Dispose();
            _popup.Dispose();
        }
        base.Dispose(disposing);
    }

    // ------------------------------------------------------------------
    // Highlighting
    // ------------------------------------------------------------------

    private void Highlight()
    {
        string text = _textBox.Text;
        if (text.Length > 300_000)
            return; // performance guard: skip coloring pathologically large buffers

        var tokens = LuauLexer.Tokenize(text);

        int savedSelectionStart = _textBox.SelectionStart;
        int savedSelectionLength = _textBox.SelectionLength;
        NativePoint scroll = GetScrollPos();

        SendMessageCore(_textBox.Handle, WmSetRedraw, (IntPtr)0, IntPtr.Zero);

        try
        {
            foreach (LuauToken token in tokens)
            {
                if (token.Kind is LuauTokenKind.Whitespace or LuauTokenKind.Identifier)
                    continue;

                _textBox.Select(token.Start, token.Length);
                _textBox.SelectionColor = TokenColor(token.Kind);
            }
        }
        finally
        {
            _textBox.Select(savedSelectionStart, savedSelectionLength);
            SendMessageCore(_textBox.Handle, WmSetRedraw, (IntPtr)1, IntPtr.Zero);
            SetScrollPos(scroll);
            _textBox.Invalidate();
        }
    }

    private static Color TokenColor(LuauTokenKind kind) => kind switch
    {
        LuauTokenKind.Keyword => AppTheme.TokenKeyword,
        LuauTokenKind.Str => AppTheme.TokenString,
        LuauTokenKind.Number => AppTheme.TokenNumber,
        LuauTokenKind.Comment => AppTheme.TokenComment,
        LuauTokenKind.Library => AppTheme.TokenBuiltin,
        LuauTokenKind.Global => AppTheme.TokenGlobal,
        LuauTokenKind.Operator => AppTheme.TokenOperator,
        _ => AppTheme.Text,
    };

    private NativePoint GetScrollPos()
    {
        var point = new NativePoint();
        SendMessagePoint(_textBox.Handle, EmGetScrollPos, IntPtr.Zero, ref point);
        return point;
    }

    private void SetScrollPos(NativePoint point)
    {
        SendMessagePoint(_textBox.Handle, EmSetScrollPos, IntPtr.Zero, ref point);
    }

    [DllImport("user32.dll", EntryPoint = "SendMessageW")]
    private static extern IntPtr SendMessageCore(IntPtr hWnd, int msg, IntPtr wParam, IntPtr lParam);

    [DllImport("user32.dll", EntryPoint = "SendMessageW")]
    private static extern IntPtr SendMessagePoint(IntPtr hWnd, int msg, IntPtr wParam, ref NativePoint lParam);

    private void OnGutterPaint(object? sender, PaintEventArgs e)
    {
        const int margin = 6;
        int lineHeight = _textBox.Font.Height;
        int firstVisible = _textBox.GetLineFromCharIndex(_textBox.GetCharIndexFromPosition(new Point(1, 1)));
        int visibleCount = _gutter.Height / lineHeight + 2;
        int currentLine = _textBox.GetLineFromCharIndex(_textBox.SelectionStart);

        using var normalBrush = new SolidBrush(AppTheme.TextMuted);
        using var activeBrush = new SolidBrush(AppTheme.Accent);
        using var font = new Font("Consolas", Math.Max(7.5f, _textBox.Font.Size - 1f));

        for (int i = 0; i < visibleCount; i++)
        {
            int line = firstVisible + i;
            int index = _textBox.GetFirstCharIndexFromLine(line);
            if (index < 0)
                break;

            int y = _textBox.GetPositionFromCharIndex(index).Y;
            if (y + lineHeight < 0 || y > _gutter.Height)
                continue;

            Color color = line == currentLine ? AppTheme.Accent : AppTheme.TextMuted;
            using var brush = line == currentLine ? activeBrush : normalBrush;
            TextRenderer.DrawText(e.Graphics, (line + 1).ToString(), font,
                new Point(_gutter.Width - margin - TextRenderer.MeasureText("00000", font).Width, y), color);
        }

        using var borderPen = new Pen(AppTheme.Border);
        e.Graphics.DrawLine(borderPen, _gutter.Width - 1, 0, _gutter.Width - 1, _gutter.Height);
    }

    // ------------------------------------------------------------------
    // Editing behavior
    // ------------------------------------------------------------------

    private void OnTextChanged(object? sender, EventArgs e)
    {
        Modified = true;
        _gutter.Invalidate();
        _highlightTimer.Stop();
        _highlightTimer.Start();
        CaretMoved?.Invoke(this, EventArgs.Empty);
    }

    private void OnSelectionChanged(object? sender, EventArgs e)
    {
        if (!_suppressEvents)
        {
            _gutter.Invalidate();
            CaretMoved?.Invoke(this, EventArgs.Empty);
        }
    }

    private void OnKeyPress(object? sender, KeyPressEventArgs e)
    {
        // Typing while the popup is open narrows the filter; navigation keys
        // are handled in OnKeyDown before they reach here.
        if (_popup.IsVisible && (char.IsLetterOrDigit(e.KeyChar) || e.KeyChar == '_'))
            _highlightTimer.Stop(); // avoid re-highlight flicker mid-word
    }

    private void OnKeyDown(object? sender, KeyEventArgs e)
    {
        if (e.KeyCode == Keys.F5 && !e.Control && !e.Shift && !e.Alt)
        {
            e.Handled = true;
            ExecuteRequested?.Invoke();
            return;
        }

        if (e.Control && e.KeyCode == Keys.S && !e.Shift && !e.Alt)
        {
            e.Handled = true;
            SaveRequested?.Invoke();
            return;
        }

        if (e.Control && e.KeyCode == Keys.Space)
        {
            e.Handled = true;
            ShowCompletion(force: true);
            return;
        }

        if (_popup.IsVisible)
        {
            if (_popup.HandleKey(e.KeyData))
            {
                e.Handled = true;
                e.SuppressKeyPress = true;
                return;
            }
            if (e.KeyCode is Keys.Left or Keys.Right or Keys.Back)
                _popup.HidePopup();
        }

        switch (e.KeyCode)
        {
            case Keys.Enter:
                HandleEnter(e);
                break;
            case Keys.Tab when e.Shift:
                HandleOutdent(e);
                break;
            case Keys.Tab:
                HandleTab(e);
                break;
        }
    }

    private void HandleEnter(KeyEventArgs e)
    {
        e.SuppressKeyPress = true;
        e.Handled = true;

        int caret = _textBox.SelectionStart;
        int lineStart = _textBox.GetFirstCharIndexOfCurrentLine();
        string linePrefix = caret >= lineStart && caret <= _textBox.TextLength
            ? _textBox.Text[lineStart..caret]
            : string.Empty;

        string indent = linePrefix.Length > 0 ? new string(' ', linePrefix.Length - linePrefix.TrimStart().Length) : string.Empty;
        string trimmed = linePrefix.TrimEnd();
        string extra = trimmed.EndsWith("then") || trimmed.EndsWith("do") || trimmed.EndsWith("function")
            || trimmed.EndsWith("else") || trimmed.EndsWith("repeat") || trimmed.EndsWith("{")
            || trimmed.EndsWith("(")
            ? Indent
            : string.Empty;

        _textBox.SelectedText = "\n" + indent + extra;
        UpdateCompletion();
    }

    private void HandleTab(KeyEventArgs e)
    {
        e.SuppressKeyPress = true;
        e.Handled = true;

        if (_textBox.SelectionLength > 0 && _textBox.GetLineFromCharIndex(_textBox.SelectionStart) != _textBox.GetLineFromCharIndex(_textBox.SelectionStart + _textBox.SelectionLength))
        {
            IndentSelection(+1);
        }
        else
        {
            _textBox.SelectedText = Indent;
        }
    }

    private void HandleOutdent(KeyEventArgs e)
    {
        e.SuppressKeyPress = true;
        e.Handled = true;
        IndentSelection(-1);
    }

    private void IndentSelection(int direction)
    {
        int firstLine = _textBox.GetLineFromCharIndex(_textBox.SelectionStart);
        int lastLine = _textBox.GetLineFromCharIndex(_textBox.SelectionStart + Math.Max(_textBox.SelectionLength, 0));
        int savedCaret = _textBox.SelectionStart;

        _suppressEvents = true;
        try
        {
            for (int line = firstLine; line <= lastLine; line++)
            {
                int index = _textBox.GetFirstCharIndexFromLine(line);
                if (index < 0)
                    continue;

                _textBox.SelectionStart = index;
                _textBox.SelectionLength = Math.Min(Indent.Length, _textBox.TextLength - index);

                if (direction > 0)
                {
                    _textBox.SelectionStart = index;
                    _textBox.SelectionLength = 0;
                    _textBox.SelectedText = Indent;
                    savedCaret += savedCaret >= index ? Indent.Length : 0;
                }
                else if (_textBox.SelectedText.Length > 0)
                {
                    int spaces = 0;
                    string selected = _textBox.SelectedText;
                    while (spaces < selected.Length && selected[spaces] == ' ')
                        spaces++;
                    _textBox.SelectionStart = index;
                    _textBox.SelectionLength = spaces;
                    if (spaces > 0)
                    {
                        _textBox.SelectedText = string.Empty;
                        savedCaret -= savedCaret > index ? Math.Min(spaces, savedCaret - index) : 0;
                    }
                }
            }

            Modified = true;
        }
        finally
        {
            _suppressEvents = false;
            _textBox.SelectionStart = Math.Max(0, savedCaret);
            _textBox.SelectionLength = 0;
            _gutter.Invalidate();
            Highlight();
        }
    }

    // ------------------------------------------------------------------
    // Autocomplete
    // ------------------------------------------------------------------

    private void OnCompletionCommitted(CompletionItem item)
    {
        var (replaceStart, prefix, _) = CompletionContext(_textBox.Text, _textBox.SelectionStart);
        int caret = _textBox.SelectionStart;

        if (replaceStart >= 0 && prefix.Length > 0)
        {
            _textBox.SelectionStart = replaceStart;
            _textBox.SelectionLength = caret - replaceStart;
        }

        _textBox.SelectedText = item.Insert;
    }

    private (int ReplaceStart, string Prefix, IReadOnlyList<CompletionItem> Items) CompletionContext(string text, int caret)
    {
        caret = Math.Min(caret, text.Length);

        int wordStart = caret;
        while (wordStart > 0 && (char.IsLetterOrDigit(text[wordStart - 1]) || text[wordStart - 1] == '_'))
            wordStart--;

        string word = text[wordStart..caret];

        if (wordStart > 0 && text[wordStart - 1] == '.')
        {
            int libStart = wordStart - 1;
            while (libStart > 0 && (char.IsLetterOrDigit(text[libStart - 1]) || text[libStart - 1] == '_'))
                libStart--;
            string library = text[libStart..(wordStart - 1)];
            var members = Completions.MembersOf(library);
            return (wordStart, word, members);
        }

        if (word.Length >= 2)
            return (wordStart, word, Completions.ForPrefix(word));

        return (-1, string.Empty, Array.Empty<CompletionItem>());
    }

    private void ShowCompletion(bool force)
    {
        var (replaceStart, prefix, items) = CompletionContext(_textBox.Text, _textBox.SelectionStart);
        if (replaceStart < 0 || (items.Count == 0 && !force))
        {
            _popup.HidePopup();
            return;
        }

        _contextWord = prefix;
        if (items.Count == 0)
            items = Completions.ForPrefix(prefix);

        Point caretScreen = _textBox.GetPositionFromCharIndex(_textBox.SelectionStart);
        caretScreen = _textBox.PointToScreen(new Point(caretScreen.X + 2, caretScreen.Y + _textBox.Font.Height + 2));
        _popup.ShowCompletions(prefix, items, caretScreen);
    }

    private void UpdateCompletion()
    {
        if (!_popup.IsVisible)
            return;

        var (replaceStart, prefix, items) = CompletionContext(_textBox.Text, _textBox.SelectionStart);
        if (replaceStart < 0 || items.Count == 0)
        {
            _popup.HidePopup();
            return;
        }

        _contextWord = prefix;
        Point caretScreen = _textBox.GetPositionFromCharIndex(_textBox.SelectionStart);
        caretScreen = _textBox.PointToScreen(new Point(caretScreen.X + 2, caretScreen.Y + _textBox.Font.Height + 2));
        _popup.ShowCompletions(prefix, items, caretScreen);
    }
}
