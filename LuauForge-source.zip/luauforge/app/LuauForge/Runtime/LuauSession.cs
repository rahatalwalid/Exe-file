using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Text;
using LuauForge.Native;
using LuauForge.Settings;

namespace LuauForge.Runtime;

public enum LuauRunStatus
{
    Ok,
    CompileError,
    RuntimeError,
    Timeout,
    Cancelled,
    MemoryLimit,
    BadArg,
    Busy,
    NativeMissing,
}

/// <summary>Outcome of one sandboxed run. Message carries errors, tracebacks, or notices.</summary>
public sealed record LuauRunResult(LuauRunStatus Status, string Message, TimeSpan Duration)
{
    public bool IsError => Status is not (LuauRunStatus.Ok or LuauRunStatus.Busy);
}

/// <summary>
/// Wraps one native LuauHost session. The session is created from the current
/// settings (time limit, memory limit, output cap, loadstring/http_get gates)
/// and can run any number of scripts; each run gets a fresh, isolated VM.
///
/// Threading: Execute is blocking and must run on a worker thread
/// (see ExecuteAsync); the Output event fires on that worker thread and is
/// marshaled to the UI thread by the caller.
/// </summary>
public sealed class LuauSession : IDisposable
{
    private IntPtr _session;
    private readonly LuauNative.OutputFn _outputFn; // keeps the delegate alive
    private readonly LuauNative.HttpFn _httpFn;
    private readonly GCHandle _selfHandle;
    private readonly HttpGate? _httpGate;
    private volatile bool _running;

    /// <summary>Raised on the execute (worker) thread for every print/warn chunk.</summary>
    public event Action<int, string>? Output;

    public static string NativeVersion => LuauNative.VersionString();

    public bool IsReady => _session != IntPtr.Zero;

    private LuauSession(HttpGate? httpGate)
    {
        _session = IntPtr.Zero;
        _httpGate = httpGate;
        _outputFn = OutputCallback;
        _httpFn = HttpCallback;
        _selfHandle = GCHandle.Alloc(this);
    }

    /// <summary>
    /// Creates a session from settings. Returns null if LuauHost.dll cannot be
    /// loaded (missing next to the executable, or wrong architecture).
    /// </summary>
    public static LuauSession? Create(AppSettings settings)
    {
        HttpGate? gate = null;
        if (settings.EnableHttpGet)
            gate = new HttpGate(settings.HttpAllowlist);

        LuauSession session;
        try
        {
            session = new LuauSession(gate);
        }
        catch (DllNotFoundException)
        {
            return null;
        }

        try
        {
            var config = new LuauNative.LuauHostConfig
            {
                TimeLimitSeconds = settings.ClampedTimeLimit,
                MemoryLimitBytes = (UIntPtr)((long)settings.ClampedMemoryLimitMb * 1024 * 1024),
                MaxOutputBytes = (UIntPtr)((long)settings.ClampedMaxOutputKb * 1024),
                EnableLoadstring = settings.EnableLoadstring ? 1 : 0,
                EnableHttpGet = gate is not null ? 1 : 0,
                CallbackContext = GCHandle.ToIntPtr(session._selfHandle),
                OnOutput = Marshal.GetFunctionPointerForDelegate(session._outputFn),
                OnHttp = gate is not null ? Marshal.GetFunctionPointerForDelegate(session._httpFn) : IntPtr.Zero,
            };

            IntPtr native = LuauNative.luauhost_session_create(ref config);
            if (native == IntPtr.Zero)
            {
                session.Dispose();
                return null;
            }

            session._session = native;
            return session;
        }
        catch (DllNotFoundException)
        {
            session.Dispose();
            return null;
        }
        catch (EntryPointNotFoundException)
        {
            session.Dispose();
            return null;
        }
        catch
        {
            session.Dispose();
            throw;
        }
    }

    /// <summary>Runs a script synchronously on the calling thread.</summary>
    public LuauRunResult Execute(string chunkName, string source)
    {
        var started = Stopwatch.StartNew();

        if (_running)
            return new LuauRunResult(LuauRunStatus.Busy, "another script is already running in this session", started.Elapsed);
        if (_session == IntPtr.Zero)
            return new LuauRunResult(LuauRunStatus.NativeMissing, "LuauHost.dll is not available", started.Elapsed);

        _running = true;
        try
        {
            byte[] chunk = LuauNative.ToUtf8Z(string.IsNullOrWhiteSpace(chunkName) ? "script" : chunkName);
            byte[] code = LuauNative.ToUtf8Z(source);
            var errorBuffer = new byte[16384];

            LuauNative.Status status = (LuauNative.Status)LuauNative.luauhost_session_execute(
                _session, chunk, code, errorBuffer, (UIntPtr)errorBuffer.Length, out UIntPtr errorLength);

            string message = errorLength > UIntPtr.Zero
                ? Encoding.UTF8.GetString(errorBuffer, 0, (int)(uint)errorLength)
                : string.Empty;

            return new LuauRunResult(MapStatus(status), message, started.Elapsed);
        }
        catch (Exception exception)
        {
            return new LuauRunResult(LuauRunStatus.RuntimeError, $"host error: {exception.Message}", started.Elapsed);
        }
        finally
        {
            _running = false;
        }
    }

    /// <summary>Runs on a background thread; safe to await from the UI thread.</summary>
    public Task<LuauRunResult> ExecuteAsync(string chunkName, string source) =>
        Task.Run(() => Execute(chunkName, source));

    /// <summary>Asks the VM to abort the current run at its next safepoint.</summary>
    public void Cancel()
    {
        if (_session != IntPtr.Zero)
            LuauNative.luauhost_session_cancel(_session);
    }

    private static LuauRunStatus MapStatus(LuauNative.Status status) => status switch
    {
        LuauNative.Status.Ok => LuauRunStatus.Ok,
        LuauNative.Status.CompileError => LuauRunStatus.CompileError,
        LuauNative.Status.RuntimeError => LuauRunStatus.RuntimeError,
        LuauNative.Status.Timeout => LuauRunStatus.Timeout,
        LuauNative.Status.Cancelled => LuauRunStatus.Cancelled,
        LuauNative.Status.MemoryLimit => LuauRunStatus.MemoryLimit,
        LuauNative.Status.BadArg => LuauRunStatus.BadArg,
        LuauNative.Status.Busy => LuauRunStatus.Busy,
        _ => LuauRunStatus.RuntimeError,
    };

    private void OutputCallback(IntPtr context, int channel, IntPtr data, UIntPtr length)
    {
        string text = LuauNative.PtrToStringUtf8(data, length);
        if (text.Length > 0)
            Output?.Invoke(channel, text);
    }

    private int HttpCallback(IntPtr context, IntPtr url, out IntPtr body, out UIntPtr bodyLength, out IntPtr error)
    {
        body = IntPtr.Zero;
        bodyLength = UIntPtr.Zero;
        error = IntPtr.Zero;

        if (_httpGate is null)
        {
            error = AllocUtf8("http_get is not configured");
            return 0;
        }

        string urlText = LuauNative.PtrToStringUtf8(url);
        if (_httpGate.TryFetch(urlText, out string bodyText, out string errorText))
        {
            byte[] bytes = Encoding.UTF8.GetBytes(bodyText);
            IntPtr buffer = LuauNative.luauhost_alloc((UIntPtr)(bytes.Length + 1));
            if (buffer == IntPtr.Zero)
            {
                error = AllocUtf8("out of memory");
                return 0;
            }

            Marshal.Copy(bytes, 0, buffer, bytes.Length);
            Marshal.WriteByte(buffer, bytes.Length, 0);
            body = buffer;
            bodyLength = (UIntPtr)bytes.Length;
            return 1;
        }

        error = AllocUtf8(errorText);
        return 0;
    }

    private static IntPtr AllocUtf8(string text)
    {
        byte[] bytes = Encoding.UTF8.GetBytes(text);
        IntPtr buffer = LuauNative.luauhost_alloc((UIntPtr)(bytes.Length + 1));
        if (buffer != IntPtr.Zero)
        {
            Marshal.Copy(bytes, 0, buffer, bytes.Length);
            Marshal.WriteByte(buffer, bytes.Length, 0);
        }
        return buffer;
    }

    public void Dispose()
    {
        if (_session != IntPtr.Zero)
            LuauNative.luauhost_session_destroy(_session);
        _session = IntPtr.Zero;

        // Free the GC handle only after the native session is gone; callbacks
        // reference the handle until destroy completes.
        if (_selfHandle.IsAllocated)
            _selfHandle.Free();
    }
}
