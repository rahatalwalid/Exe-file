using System.Text;

namespace LuauForge.Runtime;

/// <summary>
/// The only component allowed to touch the network, and only on explicit
/// request: the user must enable http_get in settings AND list hosts in the
/// allowlist. Every URL requested by a sandbox script is checked here before
/// any request is made.
/// </summary>
public sealed class HttpGate
{
    private const int MaxBodyBytes = 10 * 1024 * 1024;

    private static readonly HttpClient Client = CreateClient();

    private static HttpClient CreateClient()
    {
        var client = new HttpClient(new HttpClientHandler
        {
            AllowAutoRedirect = true,
            MaxAutomaticRedirections = 5,
        })
        {
            Timeout = TimeSpan.FromSeconds(15),
            MaxResponseContentBufferSize = MaxBodyBytes,
        };
        client.DefaultRequestHeaders.UserAgent.ParseAdd("LuauForge/1.0");
        client.DefaultRequestHeaders.Accept.ParseAdd("*/*");
        return client;
    }

    private readonly HashSet<string> _allowedHosts;

    public HttpGate(IEnumerable<string> allowlist)
    {
        _allowedHosts = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        foreach (string entry in allowlist)
        {
            string trimmed = entry.Trim();
            if (trimmed.Length > 0)
                _allowedHosts.Add(trimmed);
        }
    }

    public bool IsAllowed(string url)
    {
        if (!Uri.TryCreate(url, UriKind.Absolute, out Uri? parsed) ||
            (parsed.Scheme != Uri.UriSchemeHttp && parsed.Scheme != Uri.UriSchemeHttps))
            return false;

        if (_allowedHosts.Contains("*"))
            return true;

        string host = parsed.Host;
        if (host.Length == 0)
            return false;

        foreach (string allowed in _allowedHosts)
        {
            if (allowed.StartsWith("*."))
            {
                string suffix = allowed[1..]; // "*.example.com" -> ".example.com"
                if (host.EndsWith(suffix, StringComparison.OrdinalIgnoreCase) || host.Equals(allowed[2..], StringComparison.OrdinalIgnoreCase))
                    return true;
            }
            else if (host.Equals(allowed, StringComparison.OrdinalIgnoreCase))
            {
                return true;
            }
        }

        return false;
    }

    public bool TryFetch(string url, out string body, out string error)
    {
        body = string.Empty;
        error = string.Empty;

        if (!IsAllowed(url))
        {
            error = $"host not in allowlist: {url}";
            return false;
        }

        try
        {
            using HttpResponseMessage response = Client.GetAsync(url, HttpCompletionOption.ResponseHeadersRead).GetAwaiter().GetResult();
            response.EnsureSuccessStatusCode();

            byte[] bytes = response.Content.ReadAsByteArrayAsync().GetAwaiter().GetResult();
            if (bytes.Length > MaxBodyBytes)
            {
                error = "response exceeds the 10 MB size limit";
                return false;
            }

            body = Encoding.UTF8.GetString(bytes);
            return true;
        }
        catch (Exception exception)
        {
            error = exception.Message;
            return false;
        }
    }
}
