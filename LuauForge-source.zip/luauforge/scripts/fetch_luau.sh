#!/usr/bin/env bash
# Clones the official Luau source tree at the pinned tag into extern/luau.
# Usage: scripts/fetch_luau.sh
set -euo pipefail

TAG="0.746"
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
TARGET="$ROOT/extern/luau"

if [ -f "$TARGET/VM/include/lua.h" ]; then
    echo "Luau $TAG already present at $TARGET"
    exit 0
fi

echo "Cloning luau-lang/luau tag $TAG into $TARGET ..."
git clone --depth 1 --branch "$TAG" --single-branch https://github.com/luau-lang/luau "$TARGET"

echo "Done. Luau sources ready at $TARGET"
