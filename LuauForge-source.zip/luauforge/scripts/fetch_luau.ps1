# Clones the official Luau source tree at the pinned tag into extern/luau.
# Run once before building the native module (or let CI do it).
#
#   powershell -ExecutionPolicy Bypass -File scripts\fetch_luau.ps1

$ErrorActionPreference = "Stop"

$Tag = "0.746"
$Root = Split-Path -Parent $PSScriptRoot
$Target = Join-Path $Root "extern\luau"

if (Test-Path (Join-Path $Target "VM\include\lua.h")) {
    Write-Host "Luau $Tag already present at $Target"
    exit 0
}

Write-Host "Cloning luau-lang/luau tag $Tag into $Target ..."
git clone --depth 1 --branch $Tag --single-branch https://github.com/luau-lang/luau $Target
if ($LASTEXITCODE -ne 0) { throw "git clone failed" }

Write-Host "Done. Luau sources ready at $Target"
