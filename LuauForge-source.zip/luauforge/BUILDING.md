# Building LuauForge on Windows

Everything below was verified against this exact tree: the native sandbox
builds with CMake + MSVC, and the C# app compiles with the .NET 8 SDK.
The same steps run in CI (`.github/workflows/build.yml`) on every push.

## Prerequisites (one-time)

1. **Visual Studio 2022 Build Tools** (or full VS) with the
   *"Desktop development with C++"* workload — provides MSVC and the
   Windows SDK. Download: <https://visualstudio.microsoft.com/downloads/>
   (Build Tools 2022 is free).
2. **CMake 3.20+** — included with VS Build Tools when you tick
   *C++ CMake tools for Windows*; standalone from <https://cmake.org>.
3. **.NET 8 SDK** — <https://dotnet.microsoft.com/download/dotnet/8.0>
   (any 8.0.4xx).
4. **Git** — to fetch the Luau sources.

Open *x64 Native Tools Command Prompt for VS 2022* (Start menu) so `cl`,
`cmake`, and `dotnet` are all on PATH.

## Step 1 — fetch the official Luau sources

From the repository root (the folder containing this file):

```bat
powershell -ExecutionPolicy Bypass -File scripts\fetch_luau.ps1
```

This clones `luau-lang/luau` tag **0.746** into `extern\luau` (shallow clone,
~30 MB). The tag is pinned so builds are reproducible; `native/CMakeLists.txt`
refuses to run without it.

## Step 2 — build and test the native sandbox

```bat
cmake -S native -B build\native -A x64
cmake --build build\native --config Release
ctest --test-dir build\native -C Release --output-on-failure
```

`ctest` runs `luauhost_test.exe`, the 64-check sandbox conformance suite
(time/memory limits, frozen libraries, fresh environments, gated features,
cancellation, output caps). All checks must pass — if any fail, the sandbox
is not healthy; do not ship the DLL.

## Step 3 — stage the DLL and publish the app

```bat
copy /Y build\native\Release\LuauHost.dll app\LuauForge\native\LuauHost.dll
dotnet publish app\LuauForge -c Release -r win-x64 --self-contained true -o dist
```

`dist\` now contains:

- `LuauForge.exe` — self-contained single launch target (~70 MB; contains the
  .NET runtime, so no .NET install is needed on the target machine)
- `LuauHost.dll` — the native sandbox host (must sit next to the exe)

Run `dist\LuauForge.exe`. First launch shows the console banner with the
active sandbox limits. Settings persist to `%APPDATA%\LuauForge\settings.json`.

> Building the debug flavor? Use `-c Debug` in both builds the same way.

## Step 4 (optional) — run the editor logic tests

```bat
dotnet run -c Release --project app\EditorSmoke
```

36 headless checks over the lexer and completion database (CI runs this on
Linux too, so regressions there are caught even without Windows).

## CI

Push this folder to a GitHub repository and `.github/workflows/build.yml`
builds everything automatically: it fetches Luau, builds the native module,
runs the conformance suite with `ctest`, publishes the app, and uploads a
`LuauForge-win-x64` artifact containing `LuauForge.exe` + `LuauHost.dll`.

## Project layout

```
luauforge/
├─ native/
│  ├─ CMakeLists.txt          builds Luau libs + LuauHost.dll + tests
│  ├─ LuauHost/luauhost.h     C API (documented, consumed via P/Invoke)
│  ├─ LuauHost/LuauHost.cpp   sandbox implementation
│  └─ tests/host_test.c       sandbox conformance suite
├─ app/
│  ├─ LuauForge/              WinForms app (net8.0-windows)
│  │  ├─ Program.cs, AppTheme.cs, app.manifest, assets/luauforge.ico
│  │  ├─ Native/LuauNative.cs       P/Invoke bindings (UTF-8 marshaling)
│  │  ├─ Runtime/LuauSession.cs     session wrapper, output events
│  │  ├─ Runtime/HttpGate.cs        allowlisted network gate
│  │  ├─ Settings/AppSettings.cs    JSON-persisted settings
│  │  ├─ Editor/LuauLexer.cs        tokenizer (highlighting)
│  │  ├─ Editor/Completions.cs      completion database
│  │  ├─ Editor/CodeEditor.cs       editor control (gutter, indent, popup)
│  │  ├─ Editor/CompletionPopup.cs  autocomplete popup
│  │  └─ UI/MainWindow.cs, ConsoleView.cs, ScriptTab.cs, SettingsDialog.cs
│  └─ EditorSmoke/            headless editor tests (net8.0)
├─ scripts/fetch_luau.ps1|sh  pinned Luau clone
├─ .github/workflows/build.yml
├─ README.md, BUILDING.md, LICENSE
```

## Troubleshooting

- **`Luau sources not found`** from CMake → run `scripts\fetch_luau.ps1`.
- **`LuauHost.dll could not be loaded`** in the app → the DLL is missing next
  to the exe or built for the wrong architecture (build with `-A x64` and run
  the x64 exe).
- **LNK2019 / unresolved Luau symbols** → make sure you configured with `-A x64`
  and are building the Release config the same way CI does.
- **App starts but Execute is disabled** → see the status bar; it names the
  missing piece (usually the DLL placement from Step 3).

## Building on Linux (development convenience)

The native module also builds with g++ for the sandbox test suite
(`scripts/build_native_test.sh` mirrors the CMake lists) and the editor logic
is testable headlessly (`app/EditorSmoke`). The GUI itself requires Windows.
