# LuauForge — Luau Sandbox Studio

A standalone Windows desktop application for writing, managing, and testing
**Luau** scripts in an isolated sandbox. It embeds the **official open-source
Luau compiler and VM** (the same language implementation used by Roblox,
MIT-licensed, pinned to tag `0.746`) inside its own process — like the official
`luau` CLI, but with a modern executor-style IDE around it.

![LuauForge mark](assets/luauforge-mark-256.png)

## What it is / what it is not

| LuauForge **is** | LuauForge is **not** |
| --- | --- |
| A Luau code editor with syntax highlighting and autocomplete | A Roblox game client or UI |
| A sandboxed Luau runtime for authorized development and testing | A Roblox exploit/executor — it never touches the Roblox process |
| A way to run scripts with real limits: CPU time, memory, output caps | A way to run arbitrary code with elevated privileges |
| Filesystem- and network-free by default | A backdoor — network access is opt-in and allowlisted |

Scripts run in a **fresh, isolated Luau VM per execution** inside the app's own
process. There is no process injection, no anti-cheat interaction, and no game
manipulation of any kind — those are out of scope by design. If you want to
test game-logic code against Roblox APIs, run it inside **Roblox Studio**;
LuauForge is the tool for everything that does not need the live game.

## Features

- **Editor** — custom zero-dependency control: Luau syntax highlighting
  (keywords, strings, numbers, comments, stdlib), line numbers, auto-indent,
  block indent/outdent, autocomplete for keywords, globals, and library
  members (`string.` → `string.format(...)` …), Ctrl+Space to open manually.
- **Script tabs** — open/edit many scripts at once (`.lua` and `.luau`,
  drag-and-drop supported), dirty markers, close-with-save prompt.
- **Files** — Open (Ctrl+O), Save (Ctrl+S), Save As, New tab (Ctrl+N);
  saved as UTF-8.
- **Execution** — Execute (F5) runs the current tab in the sandbox; Stop
  aborts it at the next VM safepoint. Output, warnings, and errors stream
  into the colored console with duration and status.
- **Sandbox** (verified by a 64-case conformance suite in `native/tests/`):
  - fresh proxy-globals environment per run — nothing persists between runs
  - official `luaL_sandbox` frozen libraries; assignments to `string.format`
    and friends fail with `readonly` errors
  - no filesystem surface (`io` does not exist), `os` is the safe subset
    (`clock`, `date`, `time`, `difftime`)
  - wall-clock time limit via the VM interrupt safepoint (default 10 s)
  - memory limit via a budgeted allocator (default 256 MB) — allocation
    failure raises a catchable error, never a crash
  - stack-overflow containment (deep recursion fails cleanly)
  - `print()` and `warn()` captured into the console (tab-separated args)
  - output capture cap (default 1 MB) prevents console flooding
- **Opt-in gated features** (both **off** by default, configured in Settings):
  - `loadstring` — compile source at runtime (still sandboxed)
  - `http_get(url)` — fetch text from hosts in the allowlist; the network
    request is performed by the app (not the VM) and every URL is checked
    against the allowlist first. "Load URL" uses the same gate.
- **Settings** — time limit, memory limit, output cap, feature gates,
  allowlist, editor font size, word wrap; persisted to
  `%APPDATA%\LuauForge\settings.json`.
- **Dark theme** — slate surfaces, electric-blue accent, per-monitor DPI aware.

## Architecture

```
LuauForge.exe  (C# / WinForms, .NET 8)        UI shell: tabs, editor, console, settings
      │  P/Invoke (plain C ABI)
      ▼
LuauHost.dll  (C++ / CMake)                   Sandbox host
      │  links (static)
      ▼
Luau.Ast, Luau.Bytecode, Luau.Compiler, Luau.VM   official Luau 0.746, MIT
```

- `native/LuauHost/luauhost.h` — the C API (session create/execute/cancel/destroy)
- `native/LuauHost/LuauHost.cpp` — sandbox construction, limits, callbacks
- `native/tests/host_test.c` — the conformance suite (21 test groups, 64 checks)
- `app/LuauForge/` — the WinForms application
- `app/EditorSmoke/` — headless lexer/completion tests (runs on any OS, CI uses it)

## Standard library surface

The sandbox exposes the official Luau interpreter libraries:
`coroutine`, `table`, `string`, `math`, `os` (safe subset), `debug`
(`info`/`traceback`), `utf8`, `bit32`, `buffer`, `vector`, plus the base
globals (`print`, `warn`, `error`, `pcall`, `pairs`, `tostring`, …).
Roblox-only APIs (`game`, `workspace`, `task`, `Instance`, …) are **not**
present — this is a pure Luau environment, by design and by scope.

## Quick start (source → running app)

1. `scripts/fetch_luau.ps1` — clones the official Luau source (pinned tag)
2. Build `LuauHost.dll` with CMake + Visual Studio Build Tools
3. `dotnet publish` the app — see **[BUILDING.md](BUILDING.md)** for the
   exact commands and a ready-made GitHub Actions workflow (`.github/workflows/build.yml`)
   that produces a single-file `LuauForge.exe` on every push.

## Settings reference

| Setting | Default | Meaning |
| --- | --- | --- |
| Time limit per run | 10 s (0.1–3600) | wall-clock cap enforced by the VM interrupt |
| Memory limit per run | 256 MB (1–4096) | allocator budget; exceeding raises a catchable error |
| Console capture cap | 1024 KB | total print/warn bytes captured per run |
| `loadstring` | off | expose runtime compilation to scripts |
| `http_get` | off | expose network fetch to scripts (allowlist required) |
| Allowlist | empty | one host per line (`example.com`, `*.example.com`, `*` = all) |
| Editor font size / word wrap | 10 pt / off | editor appearance |

## Privacy & safety notes

- The app never elevates (`asInvoker` manifest) and executes scripts at the
  user's own privilege level inside its own process.
- The VM has no filesystem, no process, and no network capability; the only
  network path is the C# `HttpGate`, which runs **outside** the sandbox and
  enforces the allowlist.
- Settings live in `%APPDATA%\LuauForge\`; crash logs in the same folder.

## License

LuauForge is provided under the MIT License (see `LICENSE`). It embeds
[Luau](https://github.com/luau-lang/luau), which is MIT-licensed by Roblox
Corporation and contributors; `LICENSE` includes that notice. LuauForge is an
independent tool and is not affiliated with, endorsed by, or connected to
Roblox Corporation.
